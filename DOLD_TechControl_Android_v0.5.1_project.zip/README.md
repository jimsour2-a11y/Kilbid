# DOLD TechControl Android v0.5.2

Android APK for DOLD TechControl. XLSX remains the main database/reporting file.

## v0.5.2 field update

- removed the old fixed 250-cabinet read limit; `Kokkuvõte` is now read dynamically
- reserved empty EK rows are skipped automatically
- current FINAL workbook: 280 filled records, 254 active `Kasutusel`
- inactive cabinets remain visible/history, but do not count as `Kontrollimata`
- `Kasutuse staatus` can be changed from the app
- main screen now offers `KONTROLL / AUDIT` and `PARANDUSED / TÖÖD`
- inspector/electrician can be selected on the main screen and remembered for the current control
- custom live cabinet search suggestions replace WebView `datalist`
- electrician list is read from the intended `Elektrikutele!N6:N15` block plus names already used in history
- inspection start/end/duration are written to `Kontrollid` W:X:Y, with optional exception reason in Z
- configurable minimum inspection time (0 = timing only)
- repair mode shows open defects with filters/sorting and QR filtering by cabinet
- repair completion writes directly to the existing `Puudused` row: repairer, exact completion date/time and work description
- Android 15+ top status-bar overlap fix
- native QR scanner behavior from v0.5.1 retained
- XLSX package is modified in place; unknown sheets are not recreated or intentionally removed

## Package / update compatibility

- package: `ee.dold.kilbikontroll`
- versionCode: 52
- versionName: 0.5.2
- use the same private release signing key as v0.5.1 for install-over updates

## Build

Java 17, Gradle 8.10.2, Android compile/target SDK 35.


Canonical package from v0.5.2 onward: ee.dold.techcontrol
