# DOLD TechControl Android v0.5.1

Working update of the electrical-cabinet inspection module.

## v0.5.1 changes

- QR camera opens inside the app instead of launching a separate scanner activity.
- camera permission is handled by the app.
- electrician list is read from `Elektrikutele!N6:N100`, plus names already used in inspections/defects.
- numeric garbage such as `0` is excluded from the people list.
- `Ring` UI wording changed to `Kontroll`.
- `Kontrollimata` now means not yet checked in the current control session.
- `Täna tehtud` changed to `Kontrollitud`.
- search covers ID, device, panel, location, area, type, status and last inspector.
- search suggestions are populated from workbook data.
- overdue badges show the number of overdue days.
- XLSX export help text now describes the Android APK behavior correctly.
- application display name: `DOLD TechControl`.
- app package stays `ee.dold.kilbikontroll`, so v0.5.1 can update v0.5.0 and preserve app data.

## XLSX behavior

The workbook remains the primary database. Unknown sheets are preserved because the app edits the imported XLSX package instead of rebuilding a workbook from scratch.

## Build

Use GitHub Actions workflow `Build DOLD TechControl APK` or run Gradle `:app:assembleDebug` with Java 17 and Android SDK 35.
