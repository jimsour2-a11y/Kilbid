# DOLD TechControl Android v0.5.3

Android APK for DOLD TechControl. XLSX remains the main database/reporting file.

## v0.5.3 grouped field update

- removed the old fixed 250-cabinet read limit; `Kokkuvõte` is now read dynamically
- reserved empty EK rows are skipped automatically
- current imported workbook is read dynamically; the supplied v1.1 workbook has 280 registry rows and 250 active cabinets
- inactive cabinets remain visible/history, but do not count as `Kontrollimata`
- `Kasutuse staatus` can be changed from the app
- main screen now offers `KONTROLL / AUDIT` and `PARANDUSED / TÖÖD`
- inspector/electrician can be selected on the main screen and remembered for the current control
- custom live cabinet search suggestions replace WebView `datalist`
- electrician list is read from the intended `Elektrikutele!N6:N15` block plus names already used in history
- inspection start/end/duration are written to `Kontrollid` W:X:Y, with optional exception reason in Z
- durable internal save after every successful inspection/repair save; progress survives process death, restart and renamed workbook copies
- multi-day unfinished Kontroll cycle with explicit JÄTKA KONTROLLI / UUS KONTROLL flow
- editing updates the existing current-cycle Kontrollid row and existing Puudused rows without duplicates
- hard minimum inspection time is 60 seconds; old values below 60 are migrated/clamped
- random non-configurable QR presence challenge for list/search opened inspections
- separate Seaded tab with minimum-time and Süsteemne/Hele/Tume theme controls
- area progress statistics for the selected Ala / osakond
- timestamped external XLSX export via Android document picker; source workbook is not overwritten
- repair mode shows open defects with filters/sorting and QR filtering by cabinet
- repair completion writes directly to the existing `Puudused` row: repairer, exact completion date/time and work description
- Android 15+ top status-bar overlap fix
- native QR scanner behavior from v0.5.1 retained
- XLSX package is modified while preserving unknown sheets, formulas and existing package parts; W:X:Y:Z remain the timer columns

## Package / update compatibility

- package: `ee.dold.techcontrol`
- versionCode: 53
- versionName: 0.5.3
- the supplied installed v0.5.2 was a GitHub debug APK. Its debug certificate is not available in this source bundle, so a release signed with a new key cannot update it without a one-time uninstall/reinstall.
- for future install-over updates, configure a private Gradle release key outside the repository. Never commit the keystore or password.

## Build

Java 17, Gradle 8.10.2, Android compile/target SDK 35.

The included GitHub workflow builds a debug APK named `DOLD-TechControl-v0.5.3-debug.apk`. A stable production APK still requires the maintainer's private signing key and an Android/Gradle build environment.

## Verification

`tests/headless-regression.cjs` exercises the supplied latest workbook and covers import/counts, durable restart and renamed-import restore, multi-day continuation, editing and defect de-duplication, 60-second timer rules, QR challenge logic, area/search behavior, repair persistence, timestamped export metadata, unknown-sheet preservation, numeric duration and explicit new-cycle confirmation. The current run passes all 13 checks.


Scoring semantics remain unchanged from the supplied workbook (`0 = Ei ole / puudub`, excluded from average); the older contradictory Juhend wording was not silently changed.
