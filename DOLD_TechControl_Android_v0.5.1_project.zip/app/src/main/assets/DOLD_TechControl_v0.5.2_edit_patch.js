/* DOLD TechControl v0.5.2 hotfix: edit an inspection already saved in current Kontroll. */
(function(){
  function controlStartIso(){
    try{return localDateIso(new Date(S.ringStartedAt||Date.now()))}catch(e){return today()}
  }

  async function findCurrentInspection(id){
    if(!S.zip || !S.paths || !S.paths["Kontrollid"]) return null;
    const ctr=await loadDoc("Kontrollid");
    const startDate=controlStartIso();
    let best=null;
    for(let r=5;r<=10000;r++){
      const rid=getCellVal(ctr,"B",r).trim();
      if(!rid && r>1000) break;
      if(rid!==id) continue;
      const date=excelDateToIso(getCellVal(ctr,"A",r));
      if(date && date<startDate) continue;
      // The last matching row is the newest row in the current control period.
      best={
        row:r,
        date:date||localDateIso(),
        inspector:getCellVal(ctr,"D",r).trim(),
        ratings:Object.fromEntries(CHECKS.map(([col])=>[col,getCellVal(ctr,col,r).trim()])),
        start:Number(getCellVal(ctr,"W",r)||0),
        end:Number(getCellVal(ctr,"X",r)||0),
        duration:Number(getCellVal(ctr,"Y",r)||0),
        exception:getCellVal(ctr,"Z",r).trim()
      };
    }
    return best;
  }

  function fractionToTodayDate(frac){
    const n=Number(frac||0);
    const d=new Date();
    if(Number.isFinite(n) && n>0 && n<1){
      const total=Math.round(n*86400);
      d.setHours(Math.floor(total/3600),Math.floor((total%3600)/60),total%60,0);
    }
    return d;
  }

  openCab = async function(id){
    stopInspectionTimer();
    S.selected=S.cabinets.find(c=>c.id===id); if(!S.selected)return;
    S.ratings={}; CHECKS.forEach(([col])=>S.ratings[col]="");
    S.stagedDefects=[];
    S.editInspectionRow=null;
    S.editOriginalStart=0;
    S.editOriginalDuration=0;
    S.editOriginalException="";

    let existing=null;
    if(S.sessionChecked.has(id)){
      try{existing=await findCurrentInspection(id)}catch(e){console.warn("Kontrolli muutmise rea leidmine ebaõnnestus",e)}
    }
    if(existing){
      S.editInspectionRow=existing.row;
      S.editOriginalStart=existing.start||0;
      S.editOriginalDuration=existing.duration||0;
      S.editOriginalException=existing.exception||"";
      for(const [col] of CHECKS){
        const v=String(existing.ratings[col]??"").trim();
        S.ratings[col]=/^[0-5]$/.test(v)?v:"";
      }
    }

    const editBadge=existing?'<div class="badge warn topgap">MUUDA KONTROLLI • olemasolevat rida uuendatakse</div>':"";
    $("inspectTitle").innerHTML=`<div class="big">${esc(S.selected.id)} • ${esc(cabinetTitle(S.selected))}</div>
      <div class="small">${esc(S.selected.panel?S.selected.panel+" • ":"")}${esc(S.selected.location||"")}<br>${esc(S.selected.area)} • ${esc(S.selected.type)} • ${esc(S.selected.status)}</div>${!isActiveCabinet(S.selected)?`<div class="badge warn topgap">Ei kuulu aktiivsesse kontrolli</div>`:""}${editBadge}`;
    $("inspectionDate").value=existing?.date||localDateIso();
    $("inspector").value=existing?.inspector||S.inspector||S.selected.lastInspector||"";
    if($("inspectorQuick")){
      const v=$("inspector").value;
      $("inspectorQuick").value=S.people.includes(v)?v:"";
    }
    if($("cabStatus"))$("cabStatus").innerHTML=statusOptions(S.selected.status);
    $("inspectComment").value="";
    renderRatings(); renderStagedDefects();
    for(const idd of ["homeTab","cabTab","defTab","dataTab","repairTab"])$(idd).classList.add("hidden");
    $("inspectTab").classList.remove("hidden");

    // A new edit session has its own timer. Original W/Y are preserved and Y accumulates edit time.
    S.inspectStartedAt=new Date();
    startInspectionTimer();

    const buttons=document.querySelectorAll("#inspectTab .stickySave button");
    if(buttons[0]) buttons[0].textContent=existing?"SALVESTA MUUDATUSED":"SALVESTA";
    if(buttons[1]) buttons[1].textContent=existing?"SALVESTA MUUDATUSED + JÄRGMINE":"SALVESTA + JÄRGMINE";
    window.scrollTo(0,0);
  };

  saveInspection = async function(goNext=false){
    if(!S.zip||!S.selected)return;
    const selectedStatus=$("cabStatus")?.value||S.selected.status;
    if(!isActiveCabinet({...S.selected,status:selectedStatus})){
      if(selectedStatus!==S.selected.status) await saveCabinetStatus();
      else toast("See kilp ei kuulu aktiivsesse kontrolli. Vajadusel muuda staatust.",4000);
      return;
    }
    const inspector=$("inspector").value.trim();
    if(!inspector){toast("Sisesta kontrollija");return}
    if(!validateInspectionBeforeSave())return;

    if($("dDesc")){
      const hasAnyDefectData =
        $("dDesc").value.trim() ||
        ($("dGrade") && $("dGrade").value) ||
        ($("dOwner") && $("dOwner").value.trim()) ||
        ($("dDue") && $("dDue").value);
      if(hasAnyDefectData && !stageDefect())return;
    }

    const date=$("inspectionDate").value||localDateIso();
    const started=S.inspectStartedAt instanceof Date?S.inspectStartedAt:new Date();
    const ended=new Date();
    const editSessionSeconds=Math.max(0,(ended.getTime()-started.getTime())/1000);
    const previousSeconds=S.editInspectionRow?Math.max(0,Number(S.editOriginalDuration||0)*86400):0;
    const durationSeconds=previousSeconds+editSessionSeconds;
    const minSeconds=getMinInspectionSeconds();
    let exceptionReason=S.editInspectionRow?(S.editOriginalException||""):"";
    if(minSeconds>0 && durationSeconds<minSeconds){
      exceptionReason=prompt(`Kontroll kestis ${Math.round(durationSeconds)} s, minimaalne aeg on ${minSeconds} s.\n\nSisesta erandi põhjus:`,exceptionReason)||"";
      if(!exceptionReason.trim()){toast("Erandi põhjus on vajalik");return}
    }

    try{
      const ctr=await loadDoc("Kontrollid");
      const row=S.editInspectionRow || firstEmptyRow(ctr,"B",5,10000);
      setDate(ctr,"A",row,date);
      setInline(ctr,"B",row,S.selected.id);
      for(const [col,val] of [["C",S.selected.area],["E",S.selected.panel],["F",S.selected.device],["G",S.selected.location]]){
        const c=getCell(ctr,col+row); if(!c||!isFormulaCell(c)) setInline(ctr,col,row,val);
      }
      setInline(ctr,"D",row,inspector);
      for(const [col] of CHECKS){
        const v=String(S.ratings[col]??"");
        if(v!=="") setNum(ctr,col,row,Number(v));
        else {
          const c=getCell(ctr,col+row);
          if(c && !isFormulaCell(c)){clearCellContent(c);c.removeAttribute("t")}
        }
      }

      if(S.editInspectionRow && Number(S.editOriginalStart)>0) setNum(ctr,"W",row,Number(S.editOriginalStart));
      else setNum(ctr,"W",row,timeFraction(started));
      setNum(ctr,"X",row,timeFraction(ended));
      setNum(ctr,"Y",row,durationSeconds/86400);
      if(exceptionReason.trim()) setInline(ctr,"Z",row,exceptionReason.trim());
      else {
        const z=getCell(ctr,"Z"+row);if(z && !isFormulaCell(z)){clearCellContent(z);z.removeAttribute("t")}
      }
      S.zip.file(S.paths["Kontrollid"],xmlStr(ctr));

      if(selectedStatus!==S.selected.status){
        const sum=await loadDoc("Kokkuvõte");
        setInline(sum,"H",S.selected.row,selectedStatus);
        S.zip.file(S.paths["Kokkuvõte"],xmlStr(sum));
        S.selected.status=selectedStatus;
      }

      const newlySavedDefects=[];
      if(S.stagedDefects.length){
        const def=await loadDoc("Puudused");
        for(const d of S.stagedDefects){
          const rr=firstEmptyRow(def,"B",5,10000);
          setDate(def,"A",rr,date);setInline(def,"B",rr,S.selected.id);
          for(const [col,val] of [["C",cabinetTitle(S.selected)],["D",S.selected.location]]){
            const c=getCell(def,col+rr); if(!c||!isFormulaCell(c)) setInline(def,col,rr,val);
          }
          setInline(def,"E",rr,inspector);setInline(def,"F",rr,d.point);setInline(def,"G",rr,d.desc);
          setInline(def,"H",rr,d.grade);setInline(def,"I",rr,d.repeat);
          if(d.owner)setInline(def,"J",rr,d.owner);
          if(d.due)setDate(def,"K",rr,d.due);
          newlySavedDefects.push({row:rr,id:S.selected.id,date,point:d.point,desc:d.desc,grade:d.grade,repeat:d.repeat,owner:d.owner,due:d.due});
        }
        S.zip.file(S.paths["Puudused"],xmlStr(def));
      }

      S.inspector=inspector;
      if(!S.people.includes(inspector)){S.people.push(inspector);S.people.sort((a,b)=>a.localeCompare(b,"et"));fillPeople()}
      S.sessionChecked.add(S.selected.id);
      saveRingProgress();
      S.dirty=true;
      const thisId=S.selected.id;
      const wasEdit=!!S.editInspectionRow;
      stopInspectionTimer();
      toast(`${thisId} ${wasEdit?"muudatused salvestatud":"salvestatud"} • ${Math.round(durationSeconds)} s`);
      await refreshFromWorkbook();
      for(const nd of newlySavedDefects){
        if(!S.existingDefects.some(x=>x.row===nd.row && x.id===nd.id && x.desc===nd.desc)) S.existingDefects.push(nd);
      }
      S.sessionChecked.add(thisId);
      renderDefects();updateTop();
      S.editInspectionRow=null;
      if(goNext) openNextCabinet(thisId); else showTab("cab");
    }catch(e){console.error(e);alert("Salvestamine ebaõnnestus:\n"+e.message)}
  };
})();
