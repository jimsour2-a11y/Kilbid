/* DOLD TechControl 0.5.3. Keeps the existing JSZip workbook editor and native QR scanner.
 * A save is acknowledged only after one atomic, complete native workspace commit.
 */
const TC = {schema:1, dbId:null, registryKey:'', registryTokens:[], cycle:null,
  guard:null, revision:0, updatedAt:null, sourceHash:'', ready:false, busy:false,
  records:[], allDefects:[], pending:null, opened:null, exportPending:false, baseWorkbookBase64:''};
const META_NAME='DOLD.TechControl.v1';
const cloneData=v=>JSON.parse(JSON.stringify(v));
function cloneWorkbook(zip){const copy=zip.clone();copy.files={...zip.files};return copy;}
function uid(){const a=new Uint32Array(4);crypto.getRandomValues(a);return [...a].map(n=>n.toString(16).padStart(8,'0')).join('');}
function nativeStore(){return !!(window.Android&&typeof Android.saveWorkspace==='function');}
async function digest(bytes){
  if(nativeStore()&&typeof Android.hashBytes==='function')return Android.hashBytes(bytesToBase64(bytes));
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
}
function decode64(s){return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
async function browserDb(){return new Promise((resolve,reject)=>{const r=indexedDB.open('dold-workspaces-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('workspaces',{keyPath:'dbId'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function storeCall(kind,value){
  if(nativeStore()){
    const raw=kind==='list'?Android.listWorkspaces():kind==='get'?Android.readWorkspace(value):Android.saveWorkspace(value.dbId,JSON.stringify(value));
    const result=JSON.parse(raw);if(!result.ok)throw Error(result.error||'Sisemine salvestamine ebaõnnestus');return result.data;
  }
  const db=await browserDb();return new Promise((resolve,reject)=>{
    let tx;try{tx=db.transaction('workspaces',kind==='put'?'readwrite':'readonly',{durability:'strict'});}catch(e){tx=db.transaction('workspaces',kind==='put'?'readwrite':'readonly');}
    const os=tx.objectStore('workspaces'),r=kind==='list'?os.getAll():kind==='get'?os.get(value):os.put(value);
    tx.oncomplete=()=>{db.close();resolve(kind==='put'?true:r.result);};tx.onabort=tx.onerror=()=>{db.close();reject(tx.error||Error('Andmeid ei salvestatud'));};
  });
}
async function readMetadata(){
  const f=S.zip.file('docProps/custom.xml');if(!f)return null;
  const d=parseXml(await f.async('string')),p=qsa(d,'property').find(x=>x.getAttribute('name')===META_NAME);
  if(!p)return null;try{const m=JSON.parse(p.textContent);return m.schema===1&&m.dbId?m:null;}catch(e){throw Error('Kontrolli metaandmed on vigased. Algfaili ei muudeta.');}
}
async function writeMetadata(){
  const ns='http://schemas.openxmlformats.org/officeDocument/2006/custom-properties',vt='http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes';
  const path='docProps/custom.xml',f=S.zip.file(path);
  const d=f?parseXml(await f.async('string')):parseXml(`<Properties xmlns="${ns}" xmlns:vt="${vt}"/>`);
  let p=qsa(d,'property').find(x=>x.getAttribute('name')===META_NAME);
  if(!p){p=d.createElementNS(ns,'property');p.setAttribute('fmtid','{D5CDD505-2E9C-101B-9397-08002B2CF9AE}');p.setAttribute('pid',String(Math.max(1,...qsa(d,'property').map(x=>Number(x.getAttribute('pid'))||1))+1));p.setAttribute('name',META_NAME);d.documentElement.appendChild(p);}
  while(p.firstChild)p.removeChild(p.firstChild);
  const v=d.createElementNS(vt,'vt:lpwstr');v.textContent=JSON.stringify({schema:1,dbId:TC.dbId,registryKey:TC.registryKey,cycle:TC.cycle,revision:TC.revision,updatedAt:TC.updatedAt,inspector:S.inspector});p.appendChild(v);S.zip.file(path,xmlStr(d));
  const types=parseXml(await S.zip.file('[Content_Types].xml').async('string'));
  if(!qsa(types,'Override').some(x=>x.getAttribute('PartName')==='/'+path)){
    const x=types.createElementNS(types.documentElement.namespaceURI,'Override');x.setAttribute('PartName','/'+path);x.setAttribute('ContentType','application/vnd.openxmlformats-officedocument.custom-properties+xml');types.documentElement.appendChild(x);S.zip.file('[Content_Types].xml',xmlStr(types));
  }
  const rel=parseXml(await S.zip.file('_rels/.rels').async('string'));
  if(!qsa(rel,'Relationship').some(x=>/\/custom-properties$/.test(x.getAttribute('Type')||''))){
    const x=rel.createElementNS(rel.documentElement.namespaceURI,'Relationship');const ids=new Set(qsa(rel,'Relationship').map(x=>x.getAttribute('Id')));let id='rIdDoldControl';while(ids.has(id))id+='1';x.setAttribute('Id',id);x.setAttribute('Type','http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties');x.setAttribute('Target',path);rel.documentElement.appendChild(x);S.zip.file('_rels/.rels',xmlStr(rel));
  }
}
async function registryIdentity(){
  const tokens=S.cabinets.map(c=>[c.id,c.area,c.panel,c.device,c.location].map(v=>String(v||'').trim().toLowerCase()).join('|')).sort();
  return {tokens,key:await digest(new TextEncoder().encode(tokens.join('\n')))};
}
function recordFingerprint(r){return [r.id,r.date,r.inspector,String(r.start)].join('|');}
async function hydrateHistory(ctr,def){
  TC.records=qsa(ctr,'row').map(x=>Number(x.getAttribute('r'))).filter(r=>r>=5&&getCellVal(ctr,'B',r)).map(row=>({row,id:getCellVal(ctr,'B',row).trim(),date:excelDateToIso(getCellVal(ctr,'A',row)),inspector:getCellVal(ctr,'D',row).trim(),start:getCellVal(ctr,'W',row),end:getCellVal(ctr,'X',row),duration:Number(getCellVal(ctr,'Y',row))||0,exception:getCellVal(ctr,'Z',row),ratings:Object.fromEntries(CHECKS.map(([col])=>[col,getCellVal(ctr,col,row)]))}));
  TC.allDefects=qsa(def,'row').map(x=>Number(x.getAttribute('r'))).filter(r=>r>=5&&getCellVal(def,'B',r)).map(row=>({row,id:getCellVal(def,'B',row).trim(),date:excelDateToIso(getCellVal(def,'A',row)),inspector:getCellVal(def,'E',row),point:getCellVal(def,'F',row),desc:getCellVal(def,'G',row),grade:getCellVal(def,'H',row),repeat:getCellVal(def,'I',row),owner:getCellVal(def,'J',row),due:excelDateToIso(getCellVal(def,'K',row)),closed:!!getCellVal(def,'M',row)}));
  for(const c of S.cabinets){
    const latest=TC.records.filter(r=>r.id===c.id&&r.date).sort((a,b)=>b.date.localeCompare(a.date)||b.row-a.row)[0];
    if(latest&&(!c.lastDate||latest.date>=c.lastDate)){c.lastDate=latest.date;c.lastInspector=latest.inspector;/* Keep configured historical interval when available. */if(!c.nextDate||c.nextDate<=latest.date)c.nextDate=plusDays(latest.date,120);}
  }
  S.existingDefects=TC.allDefects.filter(d=>!d.closed);
  reconcileCycle();
}
function reconcileCycle(){
  S.sessionChecked=new Set();if(!TC.cycle)return;
  for(const [id,link] of Object.entries(TC.cycle.entries||{})){
    let r=TC.records.find(r=>r.row===link.row&&r.id===id&&(!link.fingerprint||recordFingerprint(r)===link.fingerprint));
    if(!r&&link.fingerprint)r=TC.records.find(r=>r.id===id&&recordFingerprint(r)===link.fingerprint);
    if(r){link.row=r.row;S.sessionChecked.add(id);}
  }
  S.ringStartedAt=TC.cycle.startedAt;
}
function savedEntry(id){const link=TC.cycle?.entries?.[id];return link?TC.records.find(r=>r.row===link.row&&r.id===id&&recordFingerprint(r)===link.fingerprint):null;}
function setBusy(value){TC.busy=value;document.body.classList.toggle('saving',value);}
async function persistWorkspace(){
  if(!TC.dbId||!S.zip)throw Error('Tööfail ei ole avatud');
  TC.revision++;TC.updatedAt=new Date().toISOString();await writeMetadata();await forceRecalc();
  const bytes=await S.zip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}});
  const snapshot={schema:1,dbId:TC.dbId,fileName:S.fileName,registryKey:TC.registryKey,registryTokens:TC.registryTokens,cycle:TC.cycle,guard:TC.guard,revision:TC.revision,updatedAt:TC.updatedAt,sourceHash:TC.sourceHash,baseWorkbookBase64:TC.baseWorkbookBase64,inspector:S.inspector,dirty:S.dirty,workbookBase64:bytesToBase64(bytes)};
  await storeCall('put',snapshot);return bytes;
}
async function transaction(change){
  if(TC.busy||TC.exportPending)return false;setBusy(true);
  const before={zip:cloneWorkbook(S.zip),tc:cloneData({cycle:TC.cycle,guard:TC.guard,revision:TC.revision,updatedAt:TC.updatedAt}),inspector:S.inspector,dirty:S.dirty};
  let committed=false;
  try{await change();await persistWorkspace();committed=true;await refreshFromWorkbook();renderCyclePanel();return true;}
  catch(e){if(committed){alert('Andmed on telefonis salvestatud, kuid vaadet ei saanud uuendada. Ava tööfail uuesti.\n'+e.message);return true;}S.zip=before.zip;Object.assign(TC,before.tc);S.inspector=before.inspector;S.dirty=before.dirty;await refreshFromWorkbook();alert('Andmeid EI salvestatud. Proovi uuesti.\n'+e.message);return false;}
  finally{setBusy(false);}
}
function saveRingProgress(){/* Called only for explicit inspector changes, never from rendering. */if(TC.dbId&&!TC.busy)transaction(async()=>{});}
function restoreRingProgress(){reconcileCycle();}
async function loadBook(bytes,name){S.zip=await JSZip.loadAsync(bytes,{checkCRC32:true});S.fileName=name;await loadSharedStrings();await loadSheetPaths();for(const n of ['Kokkuvõte','Kontrollid','Puudused'])if(!S.paths[n]||!S.zip.file(S.paths[n]))throw Error('Leht puudub: '+n);await refreshFromWorkbook();}
async function mergeLocalIntoIncoming(local,incoming){
  if(!local.baseWorkbookBase64)throw Error('Varasema töö baaskoopia puudub');
  const base=await JSZip.loadAsync(decode64(local.baseWorkbookBase64)),ours=await JSZip.loadAsync(decode64(local.workbookBase64));
  const merged=cloneWorkbook(incoming),skip=new Set(['docProps/custom.xml','[Content_Types].xml','_rels/.rels','xl/workbook.xml']);
  async function namedPaths(zip){const wb=parseXml(await zip.file('xl/workbook.xml').async('string')),rels=parseXml(await zip.file('xl/_rels/workbook.xml.rels').async('string')),targets=Object.fromEntries(qsa(rels,'Relationship').map(x=>[x.getAttribute('Id'),normPath(x.getAttribute('Target'))]));return Object.fromEntries(qsa(wb,'sheet').map(x=>[x.getAttribute('name'),targets[localAttr(x,'id')]]));}
  const oursPaths=await namedPaths(ours),basePaths=await namedPaths(base),incomingPaths=await namedPaths(incoming),sheetNames=Object.fromEntries(Object.entries(oursPaths).map(([k,v])=>[v,k]));
  // Reopening an older original must never remove rows already present in saved work,
  // including rows that had previously been exported. Accept only an unambiguous subset.
  let incomingOlder=false;
  for(const sheetName of ['Kontrollid','Puudused']){
    const ownDoc=parseXml(await ours.file(oursPaths[sheetName]).async('string')),otherDoc=parseXml(await incoming.file(incomingPaths[sheetName]).async('string'));
    const ownRows=qsa(ownDoc,'row').filter(r=>Number(r.getAttribute('r'))>=5&&getCellVal(ownDoc,'B',Number(r.getAttribute('r'))));
    const otherRows=qsa(otherDoc,'row').filter(r=>Number(r.getAttribute('r'))>=5&&getCellVal(otherDoc,'B',Number(r.getAttribute('r'))));
    if(ownRows.length>otherRows.length){
      for(const re of otherRows){const row=Number(re.getAttribute('r'));for(const col of sheetName==='Kontrollid'?['A','B','D','H','I','J','K','L','M','N','O','P','Q','R','W','X','Y','Z']:['A','B','E','F','G','H','I','J','K','L','M','O','P']){
        const a=getCellVal(ownDoc,col,row),b=getCellVal(otherDoc,col,row);if(a!==b&&!(a!==''&&b!==''&&Number.isFinite(Number(a))&&Number(a)===Number(b)))throw Error('Vanema koopia kirje erineb: '+sheetName+'!'+col+row);
      }}incomingOlder=true;
    }
  }
  for(const [name,entry] of Object.entries(ours.files)){
    if(entry.dir||skip.has(name))continue;
    const sheetName=sheetNames[name],basePath=sheetName?basePaths[sheetName]:name,targetPath=sheetName?incomingPaths[sheetName]:name;
    const old=basePath&&base.file(basePath)?await base.file(basePath).async('string'):null,own=await entry.async('string');
    if(incomingOlder&&(sheetName==='Kontrollid'||sheetName==='Puudused'||sheetName==='Kokkuvõte'||name==='xl/styles.xml')){if(!targetPath)throw Error('Leht puudub: '+sheetName);merged.file(targetPath,await entry.async('uint8array'));continue;}
    if(own===old)continue;
    if(!targetPath)throw Error('Valitud failis puudub muudetud leht '+sheetName);
    const other=incoming.file(targetPath)?await incoming.file(targetPath).async('string'):null;
    if(other===own)continue;if(other===old){merged.file(targetPath,await entry.async('uint8array'));continue;}
    if(!/^xl\/worksheets\/[^/]+\.xml$/.test(name)||!old||!other)throw Error('Mõlemad koopiad muutsid osa '+name);
    const a=parseXml(old),b=parseXml(own),c=parseXml(other);const am=cellMap(a),bm=cellMap(b),cm=cellMap(c);
    const value=node=>node?xmlStr(node):'';
    for(const ref of new Set([...am.keys(),...bm.keys()])){
      const av=value(am.get(ref)),bv=value(bm.get(ref)),cv=value(cm.get(ref));if(av===bv||bv===cv)continue;
      if(cv!==av)throw Error('Mõlemad koopiad muutsid lahtrit '+name+'!'+ref);
      const current=cm.get(ref),replacement=bm.get(ref);if(current)current.parentNode.removeChild(current);
      if(replacement){const row=Number(ref.match(/\d+$/)[0]),parent=rowEl(c,row),copy=c.importNode(replacement,true);const next=qsa(parent,'c').find(x=>colNum(refCol(x.getAttribute('r')))>colNum(refCol(ref)));if(next)parent.insertBefore(copy,next);else parent.appendChild(copy);cm.set(ref,copy);}else cm.delete(ref);
    }
    merged.file(targetPath,xmlStr(c));
  }
  return merged;
}
async function importXlsx(ev){
  const file=ev.target.files?.[0];if(!file||TC.busy)return;
  const old={zip:S.zip,fileName:S.fileName,tc:cloneData({...TC,opened:null,pending:null}),inspector:S.inspector,dirty:S.dirty};
  setBusy(true);stopInspectionTimer();
  try{
    const bytes=new Uint8Array(await file.arrayBuffer());TC.cycle=null;TC.ready=false;await loadBook(bytes,file.name);
    const identity=await registryIdentity(),embedded=await readMetadata(),all=await storeCall('list');
    let candidates=all.filter(x=>embedded?.dbId?x.dbId===embedded.dbId:x.registryKey===identity.key);
    // Names/locations as well as IDs must match; identical EK numbering alone is insufficient.
    if(!candidates.length&&!embedded?.dbId&&identity.tokens.length){const set=new Set(identity.tokens);candidates=all.filter(x=>{const t=x.registryTokens||[];const same=t.filter(v=>set.has(v)).length;return same/Math.max(t.length,set.size)>=0.9;});}
    if(candidates.length>1)throw Error('Sellele tabelile vastab mitu salvestatud andmebaasi. Ava viimati eksporditud XLSX, millel on andmebaasi tunnus.');
    const local=candidates[0]?await storeCall('get',candidates[0].dbId):null;
    const useIncoming=!!(embedded&&(!local||(embedded.revision||0)>(local.revision||0)));
    if(local&&!useIncoming){
      const incoming=S.zip;let merged=null,base64=local.baseWorkbookBase64,notice='Taastatud telefoni salvestatud töö. Valitud XLSX algfaili ei kirjutata üle.';
      if(await digest(bytes)!==local.sourceHash){
        try{merged=await mergeLocalIntoIncoming(local,incoming);base64=bytesToBase64(bytes);notice='Telefoni salvestatud muudatused ühendati valitud XLSX koopiaga.';}
        catch(e){if(!confirm('Valitud XLSX ja telefonis salvestatud töö sisaldavad kattuvaid muudatusi. Neid ei kirjutata automaatselt üle.\n\n'+e.message+'\n\nKas jätkata telefoni salvestatud tööga? Valitud välisfail jääb alles.'))throw e;}
      }
      await loadBook(merged?await merged.generateAsync({type:'uint8array'}):decode64(local.workbookBase64),merged?file.name:local.fileName);Object.assign(TC,{dbId:local.dbId,registryKey:identity.key,registryTokens:identity.tokens,cycle:local.cycle,guard:local.guard,revision:local.revision,updatedAt:local.updatedAt,sourceHash:merged?await digest(bytes):local.sourceHash,baseWorkbookBase64:base64});S.inspector=local.inspector||'';S.dirty=!!local.dirty;
      TC.pending={notice};
    }else{
      Object.assign(TC,{dbId:embedded?.dbId||uid(),registryKey:identity.key,registryTokens:identity.tokens,cycle:embedded?.cycle||null,guard:local?.guard||{remaining:randomGap(),pending:null},revision:embedded?.revision||0,sourceHash:await digest(bytes),baseWorkbookBase64:bytesToBase64(bytes)});S.inspector=embedded?.inspector||'';S.dirty=false;TC.pending=null;
      // An older v0.5.2 progress marker is only used if matching real records exist.
      if(!TC.cycle){let legacy;try{legacy=JSON.parse(localStorage.getItem(RING_STORAGE_KEY)||'null');}catch(e){}
        if(legacy?.startedAt&&legacy.checked?.length){const start=localDateIso(new Date(legacy.startedAt));const records=TC.records.filter(r=>legacy.checked.includes(r.id)&&r.date>=start);if(records.length){TC.cycle=cycleFromRecords(records,legacy.startedAt);S.inspector=legacy.inspector||S.inspector;}}
      }
    }
    TC.ready=false;TC.opened=null;S.stagedDefects=[];await refreshFromWorkbook();await persistWorkspace();
    $('workTabs').classList.remove('hidden');$('exportBtn').disabled=false;loadMinInspectionSetting();renderCyclePanel();showTab('home');
    toast('XLSX avatud. Vali kontrolli jätkamine või alustamine.',4000);
  }catch(e){S.zip=old.zip;S.fileName=old.fileName;Object.assign(TC,old.tc);S.inspector=old.inspector;S.dirty=old.dirty;if(S.zip){await loadSharedStrings();await loadSheetPaths();await refreshFromWorkbook();}alert('XLSX avamine ebaõnnestus. Salvestatud töö jäi alles.\n'+e.message);}
  finally{setBusy(false);ev.target.value='';}
}
function cycleFromRecords(records,startedAt){
  const cycle={id:uid(),startedAt,entries:{}};
  for(const r of records.sort((a,b)=>a.date.localeCompare(b.date)||a.row-b.row))cycle.entries[r.id]={row:r.row,fingerprint:recordFingerprint(r),defectRows:TC.allDefects.filter(d=>d.id===r.id&&d.date===r.date&&d.inspector===r.inspector).map(d=>d.row),note:''};return cycle;
}
function renderCyclePanel(){
  const box=$('cyclePanel');if(!box)return;
  const active=activeCabinets(),checked=active.filter(c=>S.sessionChecked.has(c.id)).length;
  $('fileState').innerHTML=`<b>${esc(S.fileName)}</b><br>${S.cabinets.length} objekti • aktiivses kontrollis ${active.length} • avatud puudusi ${S.existingDefects.length}<br>${S.dirty?'Muudatused on telefonis salvestatud; väline koopia on uuendamata.':'Tööfail on telefonis salvestatud.'}`;
  if(TC.cycle){box.innerHTML=`<div class="big">${checked===active.length?'Kontroll läbitud':'Pooleliolev kontroll'}</div><p>${checked} / ${active.length}<br>Alustatud: ${esc(new Date(TC.cycle.startedAt).toLocaleString('et-EE'))}</p>${TC.pending?.notice?`<p class="small">${esc(TC.pending.notice)}</p>`:''}<button class="primary" onclick="continueCycle()">JÄTKA KONTROLLI</button><button onclick="resetRingProgress()">UUS KONTROLL</button>`;}
  else{const dates=TC.records.map(r=>r.date).filter(Boolean).sort();box.innerHTML=`<div class="big">Kontrolli alustamine</div><button class="primary" onclick="resetRingProgress()">ALUSTA UUT KONTROLLI</button>${dates.length?`<details><summary>Jätka varasema versiooniga tehtud kontrolli</summary><p class="small">Vali selle läbimise tegelik alguskuupäev. Seotakse ainult selle kuupäeva ja hilisemad Kontrollid kirjed.</p><input type="date" id="legacyCycleDate" value="${esc(dates[dates.length-1])}"><button onclick="adoptHistoryCycle()">JÄTKA TABELI KONTROLLI</button></details>`:''}`;}
}
function continueCycle(){if(TC.busy)return;TC.ready=true;TC.pending=null;showTab('cab');}
async function resetRingProgress(){
  if(TC.busy||!S.zip)return;if(TC.cycle&&!confirm('Alustada uut kontrolli? Praeguse kontrolli progress nullitakse. Kõik salvestatud kontrollid ja puudused jäävad alles.'))return;
  if(await transaction(async()=>{TC.cycle={id:uid(),startedAt:new Date().toISOString(),entries:{}};S.dirty=true;})){TC.ready=true;showTab('cab');toast('Uus kontroll alustatud');}
}
async function adoptHistoryCycle(){const date=$('legacyCycleDate').value;if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return;const records=TC.records.filter(r=>r.date>=date);if(!records.length){toast('Valitud ajavahemikus kirjeid ei ole');return;}if(!confirm(`Siduda ${new Set(records.map(r=>r.id)).size} kilbi kontrollid alates ${date}?`))return;if(await transaction(async()=>{TC.cycle=cycleFromRecords(records,new Date(date+'T00:00:00').toISOString());S.dirty=true;})){TC.ready=true;showTab('cab');}}
async function openWorkMode(mode){const person=($('homePerson').value||'').trim();if(person&&person!==S.inspector){S.inspector=person;await transaction(async()=>{});}if(mode==='repair'){S.defectObjectFilter='';showTab('def');return;}if(TC.cycle)continueCycle();else{showTab('home');renderCyclePanel();toast('Alusta kõigepealt kontrolli');}}
function renderAreaStats(){const area=$('areaFilter').value,rows=activeCabinets().filter(c=>!area||c.area===area),done=rows.filter(c=>S.sessionChecked.has(c.id)).length;const box=$('areaStats');if(box)box.textContent=`${area||'Kõik alad'} • Kokku: ${rows.length} • Kontrollitud: ${done} • Kontrollimata: ${rows.length-done}`;}
function getMinInspectionSeconds(){let n=60;try{n=Number(localStorage.getItem(MIN_TIME_STORAGE_KEY)||60);}catch(e){}return Number.isFinite(n)?Math.max(60,Math.ceil(n)):60;}
function saveMinInspectionSetting(){const v=Number($('minInspectionSeconds').value),n=Number.isFinite(v)?Math.max(60,Math.ceil(v)):60;localStorage.setItem(MIN_TIME_STORAGE_KEY,String(n));$('minInspectionSeconds').value=String(n);if(TC.opened)tickInspection();}
function loadMinInspectionSetting(){const n=getMinInspectionSeconds();localStorage.setItem(MIN_TIME_STORAGE_KEY,String(n));if($('minInspectionSeconds'))$('minInspectionSeconds').value=String(n);}
function applyTheme(){const choice=localStorage.getItem('dold_theme')||'system',dark=choice==='dark'||choice==='system'&&matchMedia('(prefers-color-scheme: dark)').matches;document.documentElement.dataset.theme=dark?'dark':'light';if($('themeSetting'))$('themeSetting').value=choice;if(window.Android&&typeof Android.setTheme==='function')Android.setTheme(dark);}
function saveThemeSetting(){localStorage.setItem('dold_theme',$('themeSetting').value);applyTheme();}
function monotonicNow(){return window.Android&&typeof Android.elapsedRealtime==='function'?Number(Android.elapsedRealtime()):performance.now();}
function elapsedSeconds(){return TC.opened?Math.max(0,(monotonicNow()-TC.opened.mono)/1000):0;}
function inspectionSeconds(){return (TC.opened?.previousSeconds||0)+elapsedSeconds();}
function tickInspection(){if(!TC.opened)return;const sec=Math.floor(inspectionSeconds()),h=Math.floor(sec/3600),m=Math.floor(sec%3600/60);$('inspectionTimer').textContent=(h?String(h).padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');const remaining=Math.max(0,Math.ceil(getMinInspectionSeconds()-inspectionSeconds()));$('minimumFeedback').textContent=remaining?`Kontrolli minimaalne aeg: veel ${remaining} s`:'Minimaalne kontrolliaeg täidetud';for(const b of document.querySelectorAll('#inspectTab .stickySave button'))b.disabled=remaining>0||TC.busy;}
function startInspectionTimer(){stopInspectionTimer();tickInspection();S.inspectTimerHandle=setInterval(tickInspection,250);}
async function openCab(id,source='list'){
  if(TC.busy)return;if(!TC.ready||!TC.cycle){showTab('home');renderCyclePanel();toast('Vali JÄTKA KONTROLLI või alusta uut kontrolli');return;}
  stopInspectionTimer();S.selected=S.cabinets.find(c=>c.id===id);if(!S.selected)return;
  const existing=savedEntry(id),entry=TC.cycle.entries[id];S.editInspectionRow=existing?.row||null;
  S.ratings=Object.fromEntries(CHECKS.map(([col])=>[col,/^[0-5]$/.test(String(existing?.ratings[col]??''))?String(existing.ratings[col]):'']));
  S.stagedDefects=existing?TC.allDefects.filter(d=>entry.defectRows?.includes(d.row)&&!d.closed&&d.id===id).map(d=>({...d,existingRow:d.row})):[];
  TC.opened={id,source,proved:source==='camera',startedAt:new Date().toISOString(),mono:monotonicNow(),previousSeconds:Math.max(0,(existing?.duration||0)*86400),existing};
  S.inspectStartedAt=new Date(TC.opened.startedAt);$('defectEditor').innerHTML='';TC.editDefectIndex=null;
  $('inspectTitle').innerHTML=`<div class="big">${esc(id)} • ${esc(cabinetTitle(S.selected))}</div><div class="small">${esc(S.selected.panel)} • ${esc(S.selected.location)}<br>${esc(S.selected.area)} • ${esc(S.selected.status)}</div>${existing?'<div class="badge warn topgap">MUUDA KONTROLLI</div>':''}${!isActiveCabinet(S.selected)?'<div class="badge warn">Ei kuulu aktiivsesse kontrolli</div>':''}`;
  $('inspectionDate').value=existing?.date||localDateIso();$('inspector').value=existing?.inspector||S.inspector||S.selected.lastInspector||'';$('inspectorQuick').value=S.people.includes($('inspector').value)?$('inspector').value:'';
  $('cabStatus').innerHTML=statusOptions(S.selected.status);$('inspectComment').value=entry?.note||'';renderRatings();renderStagedDefects();
  for(const name of ['home','cab','def','data','repair','settings'])$(name+'Tab').classList.add('hidden');$('inspectTab').classList.remove('hidden');
  const buttons=document.querySelectorAll('#inspectTab .stickySave button');buttons[0].textContent=existing?'SALVESTA MUUDATUSED':'SALVESTA';buttons[1].textContent=existing?'SALVESTA MUUDATUSED + JÄRGMINE':'SALVESTA + JÄRGMINE';
  renderPresence();startInspectionTimer();window.scrollTo(0,0);
}
function randomGap(){const a=new Uint32Array(1);crypto.getRandomValues(a);return 4+a[0]%24;}
function renderPresence(){const el=$('presenceFeedback');if(!el)return;const required=TC.guard?.pending===S.selected?.id&&!TC.opened?.proved;el.innerHTML=required?`<div class="badge warn">Kohaloleku kinnitamiseks skaneeri ${esc(S.selected.id)} QR</div><br><button onclick="startPresenceScan()">SKANEERI SELLE KILBI QR</button>`:'';}
function startPresenceScan(){if(!TC.opened)return;S.qrMode='presence';if(window.Android&&typeof Android.scanQr==='function')Android.scanQr();else toast('Kohaloleku kontroll vajab Androidi kaameraskannerit',4000);}
async function ensurePresence(){
  if(TC.opened.proved)return true;
  if(TC.guard.pending||TC.guard.remaining<=1){
    if(TC.guard.pending!==S.selected.id){const ok=await transaction(async()=>{TC.guard.pending=S.selected.id;});if(!ok)return false;}
    renderPresence();startPresenceScan();return false;
  }
  return true;
}
function onNativeQrResult(raw){
  const id=normalizeQrId(raw);const proved=!!(id&&window.Android&&typeof Android.consumeQrProof==='function'&&Android.consumeQrProof(id));
  if(S.qrMode==='presence'){
    if(!TC.opened||id!==TC.opened.id||!proved){toast('Vale QR. Skaneeri '+(TC.opened?.id||'valitud kilbi')+' QR.',5000);renderPresence();return;}
    TC.opened.proved=true;renderPresence();toast('Kohalolek kinnitatud. Võid kontrolli salvestada.');return;
  }
  openQrId(raw,proved?'camera':'list');
}
function openQrId(raw,source='list'){
  const id=normalizeQrId(raw),cab=S.cabinets.find(c=>c.id===id);if(!cab){toast(id?id+' ei ole tabelis':'QR kood ei ole EK-xxx');return false;}
  if(S.qrMode==='presence'){toast('Kasuta kohaloleku kinnitamiseks kaameraskannerit');return false;}
  stopQrScanner();if(S.qrMode==='repair'){S.defectObjectFilter=id;showTab('def');renderDefects();}else openCab(id,source);return true;
}
function renderStagedDefects(){
  $('stagedDefects').innerHTML=S.stagedDefects.map((d,i)=>`<div class="miniDef"><div class="space"><b>${esc(d.grade)} - ${esc(gradeLabel(d.grade))} • ${esc(d.point)}</b><div><button class="tiny" onclick="editStagedDefect(${i})">Muuda</button>${!d.existingRow?`<button class="tiny" onclick="removeStaged(${i})">×</button>`:''}</div></div><div>${esc(d.desc)}</div><div class="small">${esc(d.owner||'Vastutaja puudub')} • ${esc(d.due||'')}${d.existingRow?' • olemasolev puudus':''}</div></div>`).join('');$('stagedCount').textContent=S.stagedDefects.length?` (${S.stagedDefects.length})`:'';
}
function editStagedDefect(i){const d=S.stagedDefects[i];addDefectForm();if(!$('dDesc'))return;TC.editDefectIndex=i;for(const [id,v] of [['dPoint',d.point],['dDesc',d.desc],['dGrade',d.grade],['dRepeat',d.repeat],['dOwner',d.owner],['dDue',d.due]])$(id).value=v||'';}
function stageDefect(){
  if(!$('dDesc'))return true;const desc=$('dDesc').value.trim(),grade=$('dGrade').value;if(!desc){toast('Kirjuta puuduse kirjeldus');return false;}if(!['A','B','C','D'].includes(grade)){toast('Vali puuduse aste');return false;}
  const i=TC.editDefectIndex;const d={...(i!=null?S.stagedDefects[i]:{}),point:$('dPoint').value,desc,grade,repeat:$('dRepeat').value,owner:$('dOwner').value.trim(),due:$('dDue').value};
  if(i!=null)S.stagedDefects[i]=d;else S.stagedDefects.push(d);TC.editDefectIndex=null;$('defectEditor').innerHTML='';renderStagedDefects();return true;
}
function removeStaged(i){if(S.stagedDefects[i]?.existingRow){toast('Olemasoleva puuduse saab sulgeda PARANDUSED vaates');return;}S.stagedDefects.splice(i,1);renderStagedDefects();}
function clearInput(doc,col,row){const c=getCell(doc,col+row);if(c&&!isFormulaCell(c)){clearCellContent(c);c.removeAttribute('t');}}
async function ensureTimeStyles(){
  const path='xl/styles.xml',doc=parseXml(await S.zip.file(path).async('string')),root=doc.documentElement,ns=root.namespaceURI;
  let fmts=qsa(doc,'numFmts')[0];if(!fmts){fmts=doc.createElementNS(ns,'numFmts');root.insertBefore(fmts,root.firstChild);}
  const xfs=qsa(doc,'cellXfs')[0];if(!xfs)throw Error('XLSX stiilid puuduvad');
  const styles={};for(const [name,code] of [['time','yyyy-mm-dd hh:mm:ss'],['duration','[HH]:MM:SS']]){
    let fmt=qsa(fmts,'numFmt').find(x=>x.getAttribute('formatCode')===code);if(!fmt){fmt=doc.createElementNS(ns,'numFmt');fmt.setAttribute('numFmtId',String(Math.max(163,...qsa(fmts,'numFmt').map(x=>Number(x.getAttribute('numFmtId'))))+1));fmt.setAttribute('formatCode',code);fmts.appendChild(fmt);}
    let list=qsa(xfs,'xf'),index=list.findIndex(x=>x.getAttribute('numFmtId')===fmt.getAttribute('numFmtId'));if(index<0){const x=list[0].cloneNode(true);x.setAttribute('numFmtId',fmt.getAttribute('numFmtId'));x.setAttribute('applyNumberFormat','1');xfs.appendChild(x);index=list.length;}styles[name]=index;
  }fmts.setAttribute('count',String(qsa(fmts,'numFmt').length));xfs.setAttribute('count',String(qsa(xfs,'xf').length));S.zip.file(path,xmlStr(doc));return styles;
}
async function saveInspection(goNext=false){
  if(TC.busy||!TC.ready||!S.selected||!TC.opened)return;
  const c=S.selected,status=$('cabStatus').value;if(!isActiveCabinet({...c,status})){if(status!==c.status)await saveCabinetStatus();else toast('See kilp ei kuulu aktiivsesse kontrolli');return;}
  if(inspectionSeconds()<getMinInspectionSeconds()){tickInspection();toast('Kontrolli minimaalne aeg ei ole täidetud');return;}
  const inspector=$('inspector').value.trim();if(!inspector){toast('Sisesta kontrollija');return;}if(!validateInspectionBeforeSave())return;
  if($('dDesc')&&!stageDefect())return;if(!await ensurePresence())return;
  const opened=TC.opened,date=$('inspectionDate').value||localDateIso();if(!/^\d{4}-\d{2}-\d{2}$/.test(date)){toast('Kontrolli kuupäev on vigane');return;}
  const duration=inspectionSeconds(),ended=new Date(),start=new Date(opened.startedAt),wasEdit=!!opened.existing;
  const ok=await transaction(async()=>{
    const ctr=await loadDoc('Kontrollid'),def=await loadDoc('Puudused'),styles=await ensureTimeStyles();
    const row=opened.existing?.row||firstEmptyRow(ctr,'B',5,Math.max(10000,...qsa(ctr,'row').map(x=>Number(x.getAttribute('r'))))+1);
    if(opened.existing&&getCellVal(ctr,'B',row)!==c.id)throw Error('Kontrolli rida on muutunud');
    setDate(ctr,'A',row,date);setInline(ctr,'B',row,c.id);setInline(ctr,'D',row,inspector);
    for(const [col,val] of [['C',c.area],['E',c.panel],['F',c.device],['G',c.location]])if(!isFormulaCell(getCell(ctr,col+row)))setInline(ctr,col,row,val);
    for(const [col] of CHECKS){const v=String(S.ratings[col]??'');if(v!=='')setNum(ctr,col,row,Number(v));else clearInput(ctr,col,row);}
    if(!wasEdit||opened.existing.start===''){setDateTime(ctr,'W',row,start);ensureCell(ctr,'W',row).setAttribute('s',styles.time);}
    setDateTime(ctr,'X',row,ended);ensureCell(ctr,'X',row).setAttribute('s',styles.time);setNum(ctr,'Y',row,duration/86400);ensureCell(ctr,'Y',row).setAttribute('s',styles.duration);
    S.zip.file(S.paths.Kontrollid,xmlStr(ctr));
    const linked=TC.cycle.entries[c.id]?.defectRows||[],defectRows=[...linked];
    for(const d of S.stagedDefects){
      let rr=d.existingRow;
      if(rr){if(getCellVal(def,'B',rr)!==c.id||getCellVal(def,'M',rr))throw Error('Puudus on vahepeal muutunud või suletud');}
      else{rr=firstEmptyRow(def,'B',5,Math.max(10000,...qsa(def,'row').map(x=>Number(x.getAttribute('r'))))+1);setDate(def,'A',rr,date);setInline(def,'B',rr,c.id);setInline(def,'E',rr,inspector);for(const [col,val] of [['C',cabinetTitle(c)],['D',c.location]])if(!isFormulaCell(getCell(def,col+rr)))setInline(def,col,rr,val);defectRows.push(rr);}
      for(const [col,val] of [['F',d.point],['G',d.desc],['H',d.grade],['I',d.repeat],['J',d.owner]])setInline(def,col,rr,val||'');if(d.due)setDate(def,'K',rr,d.due);else clearInput(def,'K',rr);
    }
    if(S.stagedDefects.length)S.zip.file(S.paths.Puudused,xmlStr(def));
    if(status!==c.status){const sum=await loadDoc('Kokkuvõte');setInline(sum,'H',c.row,status);S.zip.file(S.paths['Kokkuvõte'],xmlStr(sum));}
    const fingerprint=recordFingerprint({id:c.id,date,inspector,start:getCellVal(ctr,'W',row)});
    TC.cycle.entries[c.id]={row,fingerprint,defectRows:[...new Set(defectRows)],note:$('inspectComment').value};
    if(TC.guard.pending&&opened.proved){TC.guard.pending=null;TC.guard.remaining=randomGap();}else if(!opened.proved&&!wasEdit)TC.guard.remaining=Math.max(1,TC.guard.remaining-1);
    S.inspector=inspector;S.dirty=true;
  });
  if(ok){stopInspectionTimer();TC.opened=null;toast(`${c.id} ${wasEdit?'muudatused ':''}salvestatud telefoni • ${Math.round(duration)} s`);if(goNext)openNextCabinet(c.id);else showTab('cab');}
}
async function saveCabinetStatus(){if(TC.busy||!S.selected)return;const c=S.selected,status=$('cabStatus').value;if(await transaction(async()=>{const sum=await loadDoc('Kokkuvõte');setInline(sum,'H',c.row,status);S.zip.file(S.paths['Kokkuvõte'],xmlStr(sum));S.dirty=true;})){TC.opened=null;showTab('cab');toast(c.id+' staatus salvestatud telefoni');}}
async function saveRepair(){
  if(TC.busy||!S.selectedDefect)return;const d=S.selectedDefect,repairer=$('repairer').value.trim(),work=$('repairWork').value.trim();if(!repairer||!work){toast('Sisesta töö teostaja ja tehtud töö');return;}if(!confirm(d.id+'\nMärkida puudus parandatuks?'))return;
  if(await transaction(async()=>{const def=await loadDoc('Puudused');if(getCellVal(def,'B',d.row)!==d.id||getCellVal(def,'M',d.row))throw Error('Puudus on juba suletud või muutunud');const now=new Date(),styles=await ensureTimeStyles();setInline(def,'L',d.row,repairer);setDateTime(def,'M',d.row,now);ensureCell(def,'M',d.row).setAttribute('s',styles.time);setInline(def,'O',d.row,localTimeText(now)+' • '+work);S.zip.file(S.paths.Puudused,xmlStr(def));S.inspector=repairer;S.dirty=true;})){S.selectedDefect=null;showTab('def');toast('Parandus salvestatud telefoni');}
}
function timestampedName(){const d=new Date(),pad=n=>String(n).padStart(2,'0');let stem=S.fileName.replace(/\.xlsx$/i,'').replace(/\s*\(\d+\)$/,'').replace(/(?:_\d{2}\.\d{2}\.\d{4}|_\d{4}-\d{2}-\d{2}(?:_\d{2}[-:]?\d{2}(?:-\d{2})?)?)+$/,'');return `${stem}_${localDateIso(d)}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}.xlsx`;}
async function exportXlsx(){
  if(TC.busy||TC.exportPending||!S.zip)return;setBusy(true);
  try{const bytes=await persistWorkspace(),name=timestampedName(),mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';TC.exportPending=true;
    if(window.Android&&typeof Android.beginSaveFile==='function')await exportXlsxNative(bytes,name,mime);
    else{const a=document.createElement('a'),url=URL.createObjectURL(new Blob([bytes],{type:mime}));a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);await onNativeExportFinished(true,'XLSX koopia eksporditud');}
  }catch(e){TC.exportPending=false;alert('Eksport ebaõnnestus. Telefonis salvestatud töö jäi alles.\n'+e.message);}finally{setBusy(false);}
}
async function onNativeExportFinished(ok,message){TC.exportPending=false;if(ok){const alreadyBusy=TC.busy;setBusy(true);S.dirty=false;try{await persistWorkspace();renderCyclePanel();}catch(e){S.dirty=true;alert('Koopia eksporditud, kuid ekspordioleku salvestamine ebaõnnestus. Kontroll jäi alles.\n'+e.message);}finally{if(!alreadyBusy)setBusy(false);}toast(message||'XLSX koopia salvestatud',4000);}else alert((message||'Eksport tühistatud')+'\nTelefonis salvestatud kontroll jäi alles.');}
loadMinInspectionSetting();applyTheme();try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',applyTheme);}catch(e){}
