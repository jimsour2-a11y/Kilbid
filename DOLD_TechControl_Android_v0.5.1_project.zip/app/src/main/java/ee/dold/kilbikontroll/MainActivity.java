package ee.dold.kilbikontroll;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.BarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1101;
    private static final int CAMERA_PERMISSION_REQUEST = 1102;

    private FrameLayout rootLayout;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private FrameLayout scannerOverlay;
    private BarcodeView barcodeView;
    private boolean scannerActive = false;

    private File pendingExportFile;
    private FileOutputStream pendingExportStream;
    private String pendingExportName;
    private String pendingExportMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightSystemBars();

        rootLayout = new FrameLayout(this);
        webView = new WebView(this);
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        setContentView(rootLayout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallbackNew,
                    FileChooserParams fileChooserParams
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackNew;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                } catch (Exception e) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                }

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Failivalijat ei saanud avada", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void setLightSystemBars() {
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(
                    ViewGroup.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            );
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    /**
     * QR camera is rendered inside this Activity as an overlay over the WebView.
     * This avoids switching to another scanner Activity / external app.
     */
    private void showQrScanner() {
        if (scannerActive || rootLayout == null) return;

        scannerActive = true;
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(0);
        }

        scannerOverlay = new FrameLayout(this);
        scannerOverlay.setBackgroundColor(Color.BLACK);

        barcodeView = new BarcodeView(this);
        barcodeView.setDecoderFactory(new DefaultDecoderFactory(
                Collections.singletonList(BarcodeFormat.QR_CODE)
        ));
        scannerOverlay.addView(barcodeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // Simple scan frame. It is only a visual guide; the decoder scans the full preview.
        FrameLayout scanFrame = new FrameLayout(this);
        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setColor(Color.TRANSPARENT);
        frameBg.setStroke(dp(3), Color.WHITE);
        frameBg.setCornerRadius(dp(14));
        scanFrame.setBackground(frameBg);
        FrameLayout.LayoutParams frameParams = new FrameLayout.LayoutParams(dp(260), dp(260));
        frameParams.gravity = Gravity.CENTER;
        scannerOverlay.addView(scanFrame, frameParams);

        TextView prompt = new TextView(this);
        prompt.setText("Skaneeri elektrikilbi QR-kood");
        prompt.setTextColor(Color.WHITE);
        prompt.setTextSize(19);
        prompt.setGravity(Gravity.CENTER);
        prompt.setPadding(dp(16), dp(16), dp(16), dp(16));
        FrameLayout.LayoutParams promptParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        promptParams.gravity = Gravity.TOP;
        promptParams.topMargin = dp(24);
        promptParams.leftMargin = dp(20);
        promptParams.rightMargin = dp(20);
        scannerOverlay.addView(prompt, promptParams);

        Button cancel = new Button(this);
        cancel.setText("TÜHISTA");
        cancel.setTextSize(16);
        cancel.setOnClickListener(v -> closeQrScanner(false));
        FrameLayout.LayoutParams cancelParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        cancelParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        cancelParams.bottomMargin = dp(32);
        scannerOverlay.addView(cancel, cancelParams);

        rootLayout.addView(scannerOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        BarcodeCallback callback = new BarcodeCallback() {
            @Override
            public void barcodeResult(BarcodeResult result) {
                if (!scannerActive || result == null || result.getText() == null || result.getText().trim().isEmpty()) {
                    return;
                }
                String text = result.getText();
                runOnUiThread(() -> {
                    closeQrScanner(true);
                    sendQrResultToWeb(text);
                });
            }

            @Override
            public void possibleResultPoints(List<ResultPoint> resultPoints) {
                // No UI action needed.
            }
        };

        barcodeView.decodeSingle(callback);
        barcodeView.resume();
    }

    private void closeQrScanner(boolean success) {
        if (!scannerActive && scannerOverlay == null) return;

        scannerActive = false;
        try {
            if (barcodeView != null) barcodeView.pause();
        } catch (Exception ignored) {
        }

        if (rootLayout != null && scannerOverlay != null) {
            rootLayout.removeView(scannerOverlay);
        }
        barcodeView = null;
        scannerOverlay = null;
        setLightSystemBars();

        if (!success) {
            // Cancellation is normal. Do not show an error toast.
        }
    }

    private void requestOrLaunchQrScanner() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST
            );
        } else {
            showQrScanner();
        }
    }

    private void sendQrResultToWeb(String value) {
        if (value == null) return;
        String js = "window.onNativeQrResult(" + JSONObject.quote(value) + ");";
        webView.evaluateJavascript(js, null);
    }

    private void sendQrErrorToWeb(String value) {
        String js = "window.onNativeQrError(" + JSONObject.quote(value == null ? "" : value) + ");";
        webView.evaluateJavascript(js, null);
    }

    private void sendExportResult(boolean ok, String message) {
        runOnUiThread(() -> {
            String js = "window.onNativeExportFinished(" + (ok ? "true" : "false") + "," +
                    JSONObject.quote(message == null ? "" : message) + ");";
            webView.evaluateJavascript(js, null);
        });
    }

    private synchronized void beginExport(String fileName, String mime) throws Exception {
        closePendingExportQuietly();

        pendingExportName = sanitizeFileName(fileName);
        pendingExportMime = (mime == null || mime.isEmpty())
                ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                : mime;

        pendingExportFile = new File(getCacheDir(), "export_" + System.currentTimeMillis() + ".tmp");
        pendingExportStream = new FileOutputStream(pendingExportFile);
    }

    private synchronized void appendExportChunk(String base64Chunk) throws Exception {
        if (pendingExportStream == null) {
            throw new IllegalStateException("Export is not started");
        }
        byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
        pendingExportStream.write(bytes);
    }

    private synchronized void finishExport() {
        try {
            if (pendingExportStream == null || pendingExportFile == null) {
                throw new IllegalStateException("Export is not started");
            }

            pendingExportStream.flush();
            pendingExportStream.close();
            pendingExportStream = null;

            String destination;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingExportName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, pendingExportMime);
                values.put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Kilbikontroll"
                );
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        values
                );
                if (uri == null) {
                    throw new IllegalStateException("Downloads faili ei saanud luua");
                }

                try (FileInputStream in = new FileInputStream(pendingExportFile);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) {
                        throw new IllegalStateException("Downloads faili ei saanud avada");
                    }
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                destination = "Downloads/Kilbikontroll/" + pendingExportName;
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) {
                    throw new IllegalStateException("Downloads kaust pole saadaval");
                }
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new IllegalStateException("Downloads kausta ei saanud luua");
                }
                File outFile = new File(dir, pendingExportName);
                try (FileInputStream in = new FileInputStream(pendingExportFile);
                     FileOutputStream out = new FileOutputStream(outFile)) {
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                }
                destination = outFile.getAbsolutePath();
            }

            if (pendingExportFile.exists()) {
                pendingExportFile.delete();
            }

            pendingExportFile = null;
            pendingExportName = null;
            pendingExportMime = null;

            sendExportResult(true, "XLSX salvestatud: " + destination);
        } catch (Exception e) {
            closePendingExportQuietly();
            sendExportResult(false, e.getMessage());
        }
    }

    private synchronized void closePendingExportQuietly() {
        try {
            if (pendingExportStream != null) {
                pendingExportStream.close();
            }
        } catch (Exception ignored) {
        }
        pendingExportStream = null;

        if (pendingExportFile != null && pendingExportFile.exists()) {
            pendingExportFile.delete();
        }
        pendingExportFile = null;
    }

    private String sanitizeFileName(String name) {
        String safe = name == null ? "Kilbikontroll.xlsx" : name;
        safe = safe.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!safe.toLowerCase().endsWith(".xlsx")) {
            safe += ".xlsx";
        }
        return safe;
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void scanQr() {
            runOnUiThread(MainActivity.this::requestOrLaunchQrScanner);
        }

        @JavascriptInterface
        public void beginSaveFile(String fileName, String mime) {
            try {
                beginExport(fileName, mime);
            } catch (Exception e) {
                sendExportResult(false, e.getMessage());
            }
        }

        @JavascriptInterface
        public void writeSaveChunk(String base64Chunk) {
            try {
                appendExportChunk(base64Chunk);
            } catch (Exception e) {
                sendExportResult(false, e.getMessage());
            }
        }

        @JavascriptInterface
        public void finishSaveFile() {
            finishExport();
        }

        @JavascriptInterface
        public String getAppVersion() {
            return "0.5.1";
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showQrScanner();
            } else {
                sendQrErrorToWeb("Kaamera luba puudub");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (scannerActive && barcodeView != null) {
            try {
                barcodeView.resume();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onPause() {
        if (barcodeView != null) {
            try {
                barcodeView.pause();
            } catch (Exception ignored) {
            }
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (scannerActive) {
            closeQrScanner(false);
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        closeQrScanner(false);
        closePendingExportQuietly();
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
