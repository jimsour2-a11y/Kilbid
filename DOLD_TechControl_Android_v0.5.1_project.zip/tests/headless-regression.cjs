/* Runs the REAL app controller and bundled workbook editor under Node.
 * The small DOM adapter is for XML and form fields, not an Android/WebView emulator.
 * Usage: NODE_PATH=... node tests/headless-regression.cjs /path/input.xlsx /path/results
 */
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto'),assert=require('assert');
const modules=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
const dep=n=>require(modules?path.join(modules,n):n);
const XML=dep('xml-js'),JSZip=dep('jszip');
class XmlNode{
 constructor(data,ns='',parent=null){this.data=data;this.parentNode=parent;this.namespaceURI=ns;this.localName=(data.name||'').split(':').pop();this.nodeName=data.name;this.childNodes=[];const a=data.attributes||{};this.ns={...(parent?.ns||{})};for(const [k,v] of Object.entries(a))if(k==='xmlns')this.ns['']=v;else if(k.startsWith('xmlns:'))this.ns[k.slice(6)]=v;if(data.name)this.namespaceURI=this.ns[data.name.includes(':')?data.name.split(':')[0]:'']||ns;for(const x of data.elements||[])this.childNodes.push(new XmlNode(x,this.namespaceURI,this));}
 get attributes(){return Object.entries(this.data.attributes||{}).map(([name,value])=>({name,localName:name.split(':').pop(),value}));}
 get firstChild(){return this.childNodes[0]||null;}get documentElement(){return this.childNodes.find(x=>x.data.type==='element');}
 get textContent(){return this.data.type==='text'?this.data.text:this.childNodes.map(x=>x.textContent||'').join('');}
 set textContent(v){this.childNodes=[new XmlNode({type:'text',text:String(v)},'',this)];}
 getAttribute(n){return this.data.attributes?.[n]??null;}setAttribute(n,v){(this.data.attributes??={})[n]=String(v);}hasAttribute(n){return n in (this.data.attributes||{});}removeAttribute(n){delete (this.data.attributes||{})[n];}
 getElementsByTagName(n){return this.childNodes.flatMap(x=>[...(x.data.type==='element'&&(n==='*'||x.nodeName===n)?[x]:[]),...x.getElementsByTagName(n)]);}
 getElementsByTagNameNS(ns,n){return this.getElementsByTagName('*').filter(x=>(ns==='*'||x.namespaceURI===ns)&&(n==='*'||x.localName===n));}
 importNode(node,deep){return node.cloneNode(deep);}
 createElementNS(ns,name){return new XmlNode({type:'element',name,attributes:{}},ns);}
 appendChild(x){x.parentNode=this;this.childNodes.push(x);return x;}insertBefore(x,b){x.parentNode=this;const i=this.childNodes.indexOf(b);if(i<0)this.childNodes.push(x);else this.childNodes.splice(i,0,x);return x;}
 removeChild(x){this.childNodes.splice(this.childNodes.indexOf(x),1);x.parentNode=null;return x;}
 toData(){const d={...this.data};if(this.childNodes.length)d.elements=this.childNodes.map(x=>x.toData());else delete d.elements;return d;}
 cloneNode(deep){return new XmlNode(JSON.parse(JSON.stringify({...this.toData(),...(!deep?{elements:[]}: {})})),this.namespaceURI);}
}
class Parser{parseFromString(s){return new XmlNode(XML.xml2js(s,{compact:false,alwaysChildren:false}));}}
class Serializer{serializeToString(d){return XML.js2xml(d.toData(),{compact:false});}}
const root=path.resolve(__dirname,'..'),fixture=process.argv[2],out=path.resolve(process.argv[3]||'/tmp/dold-tests');
if(!fixture)throw Error('Pass a real XLSX fixture path');fs.mkdirSync(out,{recursive:true});
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const controller=fs.readFileSync(path.join(root,'app/src/main/assets/DOLD_TechControl_v0.5.3.js'),'utf8');
const app=[...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]).find(s=>s.includes('const S =')||s.includes('const S='));
if(!app)throw Error('App script missing');
const clock={mono:1000,offset:0};let injectFailure=false;const alerts=[],storeDir=path.join(out,'native-store');fs.mkdirSync(storeDir,{recursive:true});
const proof={id:null};const settings=new Map();
class ClockDate extends Date{constructor(...args){super(...(args.length?args:[Date.now()+clock.offset]));}static now(){return Date.now()+clock.offset;}}
function makeContext(){
 const elements=new Map();
 class El{constructor(id){this.id=id;this.value='';this.textContent='';this.disabled=false;this.style={};this.dataset={};this.children=[];this.classes=new Set();this.classList={add:(...v)=>v.forEach(x=>this.classes.add(x)),remove:(...v)=>v.forEach(x=>this.classes.delete(x)),toggle:(v,on)=>on?this.classes.add(v):this.classes.delete(v),contains:v=>this.classes.has(v)};}
  set innerHTML(s){this._html=s;for(const c of this.children)elements.delete(c);this.children=[];parseUi(s,this);if(this.tag==='select'){const options=[...s.matchAll(/<option([^>]*)>([^<]*)/g)];const o=options.find(m=>/\bselected\b/.test(m[1]))||options[0];if(o){const m=o[1].match(/value="([^"]*)"/);this.value=m?m[1]:o[2];}}}
  get innerHTML(){return this._html||'';}focus(){}click(){}remove(){elements.delete(this.id);}appendChild(x){return x;}
 }
 function parseUi(s,owner){for(const m of s.matchAll(/<(input|select|textarea|div|span|button|section|nav|datalist)[^>]*\bid="([^"]+)"[^>]*>/g)){const el=new El(m[2]);el.tag=m[1];const val=m[0].match(/\bvalue="([^"]*)"/);if(val)el.value=val[1];if(m[1]==='select'){const fragment=s.slice(m.index+m[0].length).split('</select>')[0];const opt=fragment.match(/<option[^>]*selected[^>]*>[^<]*/)||fragment.match(/<option[^>]*>[^<]*/);if(opt){const v=opt[0].match(/value="([^"]*)"/);el.value=v?v[1]:opt[0].split('>')[1];}}if(m[0].includes('hidden'))el.classes.add('hidden');elements.set(el.id,el);if(owner)owner.children.push(el.id);}}
 parseUi(html.replace(/<script[^>]*>[\s\S]*?<\/script>/g,''));const buttons=[new El('save'),new El('next')];
 const document={getElementById:id=>elements.get(id)||null,querySelectorAll:q=>q==='#inspectTab .stickySave button'?buttons:[],body:new El('body'),documentElement:new El('root'),activeElement:null,addEventListener(){},createElement:n=>new El(n)};
 const bridge={saveWorkspace(id,payload){if(injectFailure)return JSON.stringify({ok:false,error:'Injected disk full'});const target=path.join(storeDir,id+'.json'),tmp=target+'.new',fd=fs.openSync(tmp,'w');fs.writeFileSync(fd,payload);fs.fsyncSync(fd);fs.closeSync(fd);fs.renameSync(tmp,target);return JSON.stringify({ok:true,data:true});},readWorkspace(id){return JSON.stringify({ok:true,data:fs.existsSync(path.join(storeDir,id+'.json'))?JSON.parse(fs.readFileSync(path.join(storeDir,id+'.json'))):null});},listWorkspaces(){return JSON.stringify({ok:true,data:fs.readdirSync(storeDir).filter(n=>n.endsWith('.json')).map(n=>{const o=JSON.parse(fs.readFileSync(path.join(storeDir,n)));delete o.workbookBase64;delete o.baseWorkbookBase64;return o;})});},hashBytes(b){return crypto.createHash('sha256').update(Buffer.from(b,'base64')).digest('hex');},elapsedRealtime(){return clock.mono;},consumeQrProof(id){const ok=proof.id===id;proof.id=null;return ok;},scanQr(){},setTheme(){}};
 const cx={console,document,Android:bridge,DOMParser:Parser,XMLSerializer:Serializer,JSZip,Uint8Array,Uint32Array,TextEncoder,Date:ClockDate,crypto:crypto.webcrypto,performance:{now:()=>clock.mono},setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){},localStorage:{getItem:k=>settings.get(k)??null,setItem:(k,v)=>settings.set(k,String(v)),removeItem:k=>settings.delete(k)},matchMedia:()=>({matches:false,addEventListener(){}}),alert:m=>alerts.push(String(m)),confirm:()=>true,btoa:b=>Buffer.from(b,'binary').toString('base64'),atob:b=>Buffer.from(b,'base64').toString('binary'),location:{protocol:'file:'},Blob,URL};
 cx.window=cx;cx.window.scrollTo=()=>{};cx.window.addEventListener=()=>{};vm.createContext(cx);vm.runInContext(app,cx,{filename:'index-controller.js'});vm.runInContext(controller,cx,{filename:'v053-controller.js'});
 return {cx,run:s=>vm.runInContext(s,cx),el:id=>elements.get(id),buttons};
}
let env=makeContext();const run=s=>env.run(s);const el=id=>env.el(id);
async function importBytes(bytes,name='test.xlsx'){env.cx.incoming=new Uint8Array(bytes);await run(`importXlsx({target:{files:[{name:${JSON.stringify(name)},arrayBuffer:async()=>incoming.buffer}],value:'x'}})`);}
function advance(s){clock.mono+=s*1000;clock.offset+=s*1000;}
async function count(sheet){return run(`(async()=>{const d=await loadDoc(${JSON.stringify(sheet)});return qsa(d,'row').filter(r=>Number(r.getAttribute('r'))>=5&&getCellVal(d,'B',Number(r.getAttribute('r')))).length;})()`);}
const results=[];async function test(name,fn){try{await fn();results.push({name,status:'PASS'});console.log('PASS',name);}catch(e){results.push({name,status:'FAIL',error:e.stack});console.error('FAIL',name,e);console.error('STATE',run("({busy:TC.busy,ready:TC.ready,cycle:TC.cycle,selected:S.selected?.id,status:$('cabStatus')?.value,seconds:inspectionSeconds(),guard:TC.guard,inspector:$('inspector')?.value,toast:$('toast')?.textContent})"));console.error('ALERTS',alerts);throw e;}}
(async()=>{
const bytes=fs.readFileSync(fixture);const original=await JSZip.loadAsync(bytes);let initialRows,initialDefects,id,other,firstRow,firstStart,cycleId;
await test('A import current workbook, dynamic active count, reserve IDs hidden',async()=>{
 await importBytes(bytes);if(alerts.length)throw Error(alerts.join('\n'));const stats=run(`({total:S.cabinets.length,active:activeCabinets().length,people:S.people,ids:S.cabinets.map(c=>c.id)})`);assert(stats.total>250);assert(!stats.ids.includes('EK-400'));console.log('INPUT',stats.total,stats.active);initialRows=await count('Kontrollid');initialDefects=await count('Puudused');id=run('activeCabinets().find(c=>!c.lastDate)?.id||activeCabinets()[0].id');other=run('activeCabinets().find(c=>c.id!=='+JSON.stringify(id)+').id');await run('resetRingProgress()');cycleId=run('TC.cycle.id');assert.equal(el('progressTxt').textContent,'0 / '+stats.active);
});
await test('G hard minimum and old setting migration',async()=>{
 settings.set('dold_min_inspection_seconds_v1','0');run('loadMinInspectionSetting()');assert.equal(run('getMinInspectionSeconds()'),60);el('minInspectionSeconds').value='59';run('saveMinInspectionSetting()');assert.equal(run('getMinInspectionSeconds()'),60);
 await run('openCab('+JSON.stringify(id)+')');el('inspector').value='Test Electrician';run('setAllScores(4)');await run('saveInspection()');assert.equal(await count('Kontrollid'),initialRows);advance(59);await run('saveInspection()');assert.equal(await count('Kontrollid'),initialRows);advance(2);
});
await test('B save complete workbook, F last inspection appears immediately',async()=>{
 run(`S.stagedDefects=[{point:'Skeem',desc:'Regression defect',grade:'C',repeat:'Ei',owner:'Test Electrician',due:plusDays(today(),30)}]`);await run('saveInspection()');assert.equal(await count('Kontrollid'),initialRows+1);assert.equal(await count('Puudused'),initialDefects+1);assert(run('S.sessionChecked.has('+JSON.stringify(id)+')'));assert(run('S.cabinets.find(c=>c.id==='+JSON.stringify(id)+').lastDate'));firstRow=run('TC.cycle.entries['+JSON.stringify(id)+'].row');firstStart=run('savedEntry('+JSON.stringify(id)+').start');
});
await test('B/C process restart, next day, renamed original import restores cycle',async()=>{
 env=makeContext();advance(86400);await importBytes(bytes,'renamed_2026-09-25_12-00.xlsx');assert.equal(run('TC.cycle.id'),cycleId);assert(run('S.sessionChecked.has('+JSON.stringify(id)+')'));assert.equal(await count('Kontrollid'),initialRows+1);run('continueCycle()');
 el('stateFilter').value='done';run('renderCabinets()');assert(el('cabList').innerHTML.includes(id));el('stateFilter').value='unchecked';run('renderCabinets()');assert(!el('cabList').innerHTML.includes(id));
});
await test('D/E edit updates same row and existing defect without duplicates',async()=>{
 await run('openCab('+JSON.stringify(id)+')');assert.equal(run('S.ratings.H'),'4');assert.equal(run('S.stagedDefects.length'),1);run(`S.ratings.H='5';S.stagedDefects[0].desc='Corrected existing defect'`);advance(1);await run('saveInspection()');assert.equal(await count('Kontrollid'),initialRows+1);assert.equal(await count('Puudused'),initialDefects+1);assert.equal(run('TC.cycle.entries['+JSON.stringify(id)+'].row'),firstRow);assert.equal(run('savedEntry('+JSON.stringify(id)+').start'),firstStart);assert.equal(run('savedEntry('+JSON.stringify(id)+').ratings.H'),'5');
});
await test('Disk failure never acknowledged; workbook and counter roll back',async()=>{
 await run('openCab('+JSON.stringify(other)+')');el('inspector').value='Test Electrician';run('setAllScores(5)');advance(65);injectFailure=true;await run('saveInspection()');injectFailure=false;assert.equal(await count('Kontrollid'),initialRows+1);assert(!run('S.sessionChecked.has('+JSON.stringify(other)+')'));assert(alerts.some(x=>x.includes('EI salvestatud')));await run('saveInspection()');assert.equal(await count('Kontrollid'),initialRows+2);
});
await test('H unpredictable challenge persists, wrong/manual QR rejected, matching camera accepted',async()=>{
 const next=run('activeCabinets().find(c=>!S.sessionChecked.has(c.id)).id');await run('openCab('+JSON.stringify(next)+')');run('TC.guard.remaining=1;setAllScores(4)');el('inspector').value='Test Electrician';advance(65);await run('saveInspection()');assert.equal(run('TC.guard.pending'),next);const rows=await count('Kontrollid');proof.id=other;run('onNativeQrResult('+JSON.stringify(other)+')');await run('saveInspection()');assert.equal(await count('Kontrollid'),rows);run('openQrId('+JSON.stringify(next)+')');assert(!run('TC.opened.proved'));
 env=makeContext();await importBytes(bytes);run('continueCycle()');assert.equal(run('TC.guard.pending'),next);await run('openCab('+JSON.stringify(next)+')');run('setAllScores(4)');el('inspector').value='Test Electrician';advance(65);run('startPresenceScan()');proof.id=next;run('onNativeQrResult('+JSON.stringify(next)+')');assert(run('TC.opened.proved'));await run('saveInspection()');assert.equal(run('TC.guard.pending'),null);assert(run('TC.guard.remaining>=4&&TC.guard.remaining<=27'));
 const qrId=run('activeCabinets().find(c=>!S.sessionChecked.has(c.id)).id');run("TC.guard.remaining=1;S.qrMode='audit'");proof.id=qrId;await run('onNativeQrResult('+JSON.stringify(qrId)+')');assert(run('TC.opened.proved'));run('setAllScores(4)');el('inspector').value='Test Electrician';advance(65);await run('saveInspection()');assert(run('S.sessionChecked.has('+JSON.stringify(qrId)+')'));assert.equal(run('TC.guard.pending'),null);
});
await test('I selected area counts and J live search remain correct',async()=>{
 el('areaFilter').value=run('S.cabinets.find(c=>c.id==='+JSON.stringify(id)+').area');run('renderCabinets()');const area=el('areaFilter').value;const total=run('activeCabinets().filter(c=>c.area==='+JSON.stringify(area)+').length');assert(el('areaStats').textContent.includes('Kokku: '+total));
 el('search').value='Raiman';run('updateSearchSuggestions()');assert(el('searchSuggestBox').innerHTML.includes('EK-'));el('search').value='NO_MATCH_12345';run('updateSearchSuggestions()');assert(el('searchSuggestBox').innerHTML.includes('Midagi ei leitud'));assert(!el('searchSuggestBox').innerHTML.includes('EK-'));el('search').value=id;run('updateSearchSuggestions()');assert(el('searchSuggestBox').innerHTML.includes(id));
});
await test('Repair updates only Puudused and persists immediately',async()=>{
 const before=await count('Kontrollid');const row=run("S.existingDefects.find(d=>d.desc==='Corrected existing defect').row");run('openDefectRepair('+row+')');el('repairer').value='Test Electrician';el('repairWork').value='Repair regression';await run('saveRepair()');assert.equal(await count('Kontrollid'),before);assert(!run('S.existingDefects.some(d=>d.row==='+row+')'));env=makeContext();await importBytes(bytes);assert(!run('S.existingDefects.some(d=>d.row==='+row+')'));
});
await test('L timestamp export metadata restores full cycle from external copy',async()=>{
 assert(/_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\.xlsx$/.test(run('timestampedName()')));const checked=run('S.sessionChecked.size');const data=await run('persistWorkspace()');fs.writeFileSync(path.join(out,'exported.xlsx'),data);
 for(const f of fs.readdirSync(storeDir))fs.unlinkSync(path.join(storeDir,f));env=makeContext();await importBytes(data,'external_copy.xlsx');assert.equal(run('TC.cycle.id'),cycleId);assert.equal(run('S.sessionChecked.size'),checked);assert.equal(run('savedEntry('+JSON.stringify(id)+').row'),firstRow);
});
await test('M original ZIP parts/sheets/formulas retained; numeric duration',async()=>{
 const result=await JSZip.loadAsync(fs.readFileSync(path.join(out,'exported.xlsx')));for(const name of Object.keys(original.files)){assert(result.files[name],'Missing ZIP entry '+name);}
 const allowed=new Set(['docProps/custom.xml','[Content_Types].xml','_rels/.rels','xl/workbook.xml','xl/styles.xml',run('S.paths.Kontrollid'),run('S.paths.Puudused'),run("S.paths['Kokkuvõte']")]);for(const name of Object.keys(original.files)){if(original.files[name].dir||allowed.has(name))continue;assert((await original.file(name).async('nodebuffer')).equals(await result.file(name).async('nodebuffer')),'Unexpected change '+name);}
 const d=await run("loadDoc('Kontrollid')");const y=env.cx;assert(run('savedEntry('+JSON.stringify(id)+').duration>=60/86400'));assert.equal(run('Object.keys(S.paths).length'),8);
});
await test('Unknown future sheet added externally survives reimport with pending local work',async()=>{
 const incoming=await JSZip.loadAsync(bytes);
 const sheet='<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>KEEP FUTURE MODULE</t></is></c></row></sheetData></worksheet>';
 incoming.file('xl/worksheets/future.xml',sheet);
 let wb=await incoming.file('xl/workbook.xml').async('string');wb=wb.replace('</sheets>','<sheet name="Future module" sheetId="99" r:id="rIdFuture"/></sheets>');incoming.file('xl/workbook.xml',wb);
 let rel=await incoming.file('xl/_rels/workbook.xml.rels').async('string');rel=rel.replace('</Relationships>','<Relationship Id="rIdFuture" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/future.xml"/></Relationships>');incoming.file('xl/_rels/workbook.xml.rels',rel);
 let types=await incoming.file('[Content_Types].xml').async('string');types=types.replace('</Types>','<Override PartName="/xl/worksheets/future.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>');incoming.file('[Content_Types].xml',types);
 const checked=run('S.sessionChecked.size');await importBytes(await incoming.generateAsync({type:'nodebuffer'}),'with_future.xlsx');assert(run("!!S.paths['Future module']"));assert.equal(run('S.sessionChecked.size'),checked);const text=await run("S.zip.file(S.paths['Future module']).async('string')");assert.equal(text,sheet);
});
await test('New cycle needs confirmation and preserves historical records',async()=>{
 const before=await count('Kontrollid'),old=run('TC.cycle.id');env.cx.confirm=()=>false;await run('resetRingProgress()');assert.equal(run('TC.cycle.id'),old);env.cx.confirm=()=>true;await run('resetRingProgress()');assert.notEqual(run('TC.cycle.id'),old);assert.equal(run('S.sessionChecked.size'),0);assert.equal(await count('Kontrollid'),before);
});
fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({adapter:'Node VM with XML/form adapter and fsync-backed bridge; not Android/WebView',input:path.basename(fixture),results},null,2));console.log('PASS ALL',results.length);
})().catch(e=>{fs.writeFileSync(path.join(out,'results.json'),JSON.stringify({results,alerts,error:e.stack},null,2));process.exitCode=1;});
