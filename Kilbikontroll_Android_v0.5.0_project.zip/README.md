# Kilbikontroll Android v0.5.0

Android APK branch based on the fixed web version v0.4.7.

## Native Android additions

- native QR scanner using the phone camera
- Android system file picker for XLSX import
- XLSX export directly to `Downloads/Kilbikontroll`
- browser `localStorage` remains available inside WebView, so Ring progress is preserved
- DOLD launcher icon
- app package: `ee.dold.kilbikontroll`
- author shown in the app: Vova
- app version: 0.5.0

## Cloud build with GitHub Actions

1. Put this project in a GitHub repository.
2. Open the repository `Actions` tab.
3. Run `Build Kilbikontroll APK`.
4. Download the artifact `Kilbikontroll-v0.5.0-debug`.
5. Install the APK on Android.

The debug APK is signed automatically with a debug key and is intended for testing.
A permanent release APK should later use a private release signing key.
