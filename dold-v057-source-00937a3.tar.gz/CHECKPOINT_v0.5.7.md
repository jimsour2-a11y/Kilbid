# DOLD TechControl v0.5.7 — Final Verification Checkpoint

Date: 2026-10-28

## SOURCE

- Branch: `foundation-v0.5.7`
- Transport implementation: `6c78cc1a34cd7f724e6029cca3271ea5fef32ed8`
- Diagnostic log implementation: `456e9616636f6e51f257f628ff80c01ac9d8095b`
- Allkirjad UI implementation: `f1d61b07a179d04476433da08707f53ea1a2c857`
- Version implementation: `c09a59d59dc00a221c2611b407aad63ea0d0e900`
- Final test-harness compatibility implementation: `fa6d37b884be1c915ec78c1ddf1af12233cb14f2`
- Reused signature-row formula implementation: `8227309e29471405e17381e6446f7686e549bb20`

## VERSION

- Package: `ee.dold.techcontrol`
- `versionName`: `0.5.7`
- `versionCode`: `58`

## IMPLEMENTED

- Authenticated chunked LAN transfer for large `.dtcs` baseline and delta packages. Chunks are approximately 256 KiB. The complete package size and SHA-256 are verified before the existing semantic importer runs.
- `.dtc` and `.dtcs` Android Share MIME is `application/zip`; XLSX Share MIME is unchanged. ZIP manifest routing remains authoritative.
- Bounded persistent diagnostic log with copy, text export and clear actions in Seaded.
- Dedicated responsive `Allkirjad` top tab using the existing signature draft store and production signature functions.
- Production version bump to `0.5.7 / 58` without changing package ID, sync schema, XLSX schema or signature contract.
- Isolated field-fix VM test harness now supplies the existing production `diagLog()` dependency. No production runtime code changed for this compatibility adjustment.
- Reused signature rows preserve their structural formula contract: Parandused captures the row-specific J formula before clearing data-owned cells, while Allkirjad permits only the exact approved production G/T formulas in a claimed blank-ID row. All other pre-existing formulas remain strict preservation checks.

## PRODUCTION XLSX COMPATIBILITY

Checked on a copy of `DOLD_elektrikilbi_sisekontroll_v1.3(4).xlsx`.

- Source size: `1,056,445` bytes.
- Source SHA-256: `b2ef38193331963f36798dc1c11b8a9c8bef86df65b0900cd6ec5e95ed750278`.
- OOXML ZIP CRC validation: PASS.
- All required sheets are present: `Kontrollid`, `Puudused`, `Parandused`, `Allkirjad`, `Allkirja_jaljed`, `Allkirjade pildid`, `Kontrollakt Auto`.
- App parser import, controlled Android save/export and re-import: PASS.
- OOXML preservation: `31/31 PASS`. Existing formulas, defined names, relationships, unknown parts, media, drawings, metadata, Rich Data and Picture-in-Cell parts were retained.

### Reused-row signature verification

- Kontroll production signature reused `Allkirjad!5`: PASS. The claimed row received the exact approved production G/T formulas; all other formulas and worksheet structures remained unchanged.
- Parandus production record reused `Parandused!5`: PASS. The original row-specific `Parandused!J5` formula was captured before the data row was cleared and was restored unchanged.
- Fresh-row Kontroll and Parandus controls on the approved R4 fixture: PASS.
- Hashes, proof, complete raw strokes, Rich Data, Picture-in-Cell, metadata relationships, ZIP CRC, idempotent retry and export/re-import: PASS.
- Targeted reused/fresh application scenarios: `4/4 PASS`. The S1 native signature core invoked by the runners remained `38/38 PASS`.

The earlier `SIGNATURE_STRUCTURE_UNSUPPORTED` and `OOXML_PRESERVATION_FAILED` results were production reuse-row ordering/preservation defects, not defects in the cleaned workbook. The XLSX schema was not changed.

The supplied cleaned production workbook was separately confirmed in Microsoft Excel Desktop to open without Recovery, preserve Data Validation, and survive save/close/reopen. That confirmation applies to the source workbook; an Android-exported workbook after this reused-row fix still requires physical Excel acceptance.

## FINAL AUTOMATED VERIFICATION

- Approved-fixture headless regression: `103/103 PASS`.
- R1 package routing: `10/10 PASS` within the headless pass.
- R3 direct sync and cycle: `42/42 PASS` within the headless pass.
- Large baseline plus both chunked delta directions: `2/2 PASS` within the headless pass.
- R4 semantic bidirectional sync/conflicts/idempotency: `46/46 PASS`.
- R5 transaction and recovery safety: `98/98 PASS`.
- Production XLSX/OOXML preservation: `31/31 PASS`.
- Diagnostic log: Java `6/6 PASS`; JS/UI `10/10 PASS`.
- Allkirjad UI: `16/16 PASS`.
- S1 native signature core: `38/38 PASS`.
- S2 Kontroll production signature: `18/18 PASS`.
- S3 Parandus production signature on the approved R4 contract fixture: `6/6 PASS`.
- Native LAN R2: `23/23 PASS` on the targeted rerun. One earlier stress run reported a transient listener check at iteration 15; the immediate isolated rerun passed without production changes.
- Native LAN R4: `4/4 PASS`.
- Native chunk transport: `5/5 PASS` through 20 MiB.
- Field-fix handshake: JS `11/11 PASS`; native `4/4 PASS`.
- Share/package contract: `6/6 PASS`.
- Responsive modal contract: `8/8 PASS`.
- JavaScript syntax: PASS.
- `git diff --check`: PASS.

## PRE-EXISTING BASELINE FAILURE

- Legacy R3 single-frame test expects `STARTED`, but a package larger than 1 MiB returns `PAYLOAD_TOO_LARGE`. This behavior was reproduced on clean baseline `08a29ead24aa3bf4a8418bd080bb85e6cb5df1ed` and is not a regression from the chunked transport implementation. The current chunked large-baseline path passes.

## PENDING PHYSICAL ACCEPTANCE

1. Install v0.5.7 on OnePlus 13.
2. Install v0.5.7 on CAT S42.
3. Initialize a large production baseline through QR/LAN.
4. Verify Phone A to Phone B sync.
5. Verify Phone B to Phone A sync.
6. Repeat sync and confirm no duplicates.
7. Transfer `.dtcs` through Android Share, Quick Share and Bluetooth.
8. Verify `KOPEERI LOGI` and exported diagnostic text.
9. Verify the Allkirjad tab on the narrow CAT S42 viewport.
10. Create Kontroll and Parandus signatures that reuse row 5 in the cleaned production v1.3 workbook, export it, and open the result in Microsoft Excel Desktop.

## BUILD STATUS

- GitHub Actions build and APK metadata verification are pending publication of this final branch HEAD.
- Physical Android and Microsoft Excel Desktop results are not claimed by this checkpoint.
