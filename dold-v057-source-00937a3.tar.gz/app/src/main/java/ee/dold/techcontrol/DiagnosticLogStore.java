package ee.dold.techcontrol;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** App-private bounded diagnostic text log, kept outside XLSX and workspace snapshots. */
public final class DiagnosticLogStore {
    public static final long DEFAULT_MAX_BYTES = 1536L * 1024L;
    private static final Pattern SAFE_ID = Pattern.compile("[A-Z0-9_]{1,48}");
    private static final Pattern LONG_SECRET = Pattern.compile("(?i)(?:[a-f0-9]{48,}|[a-z0-9+/]{80,}={0,2})");
    private final File file;
    private final long maxBytes;

    public DiagnosticLogStore(File filesDir) { this(filesDir, DEFAULT_MAX_BYTES); }
    DiagnosticLogStore(File filesDir, long maxBytes) {
        file = new File(filesDir, "diagnostic.log");
        this.maxBytes = Math.max(1024L, maxBytes);
    }

    public synchronized void append(String timestamp, String level, String component, String event, String fields) throws Exception {
        String cleanFields = sanitizeFields(fields);
        String line = "[" + safeText(timestamp, 32) + "] " + id(level, "INFO") + " " + id(component, "APP") + " " + id(event, "EVENT")
                + (cleanFields.isEmpty() ? "" : " " + cleanFields) + "\n";
        File parent = file.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) throw new IllegalStateException("Diagnostic directory unavailable");
        try (FileOutputStream out = new FileOutputStream(file, true)) {
            out.write(line.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        }
        rotate();
    }

    public synchronized String read() throws Exception {
        return file.exists() ? new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8) : "";
    }

    public synchronized Stats stats() throws Exception {
        String text = read();
        String[] lines = text.isEmpty() ? new String[0] : text.split("\\n");
        String lastAt = "";
        if (lines.length > 0 && lines[lines.length - 1].startsWith("[")) {
            int end = lines[lines.length - 1].indexOf(']');
            if (end > 1) lastAt = lines[lines.length - 1].substring(1, end);
        }
        return new Stats(lines.length, text.getBytes(StandardCharsets.UTF_8).length, lastAt);
    }

    public synchronized void clear() throws Exception {
        File parent = file.getParentFile();
        if (!parent.exists() && !parent.mkdirs()) throw new IllegalStateException("Diagnostic directory unavailable");
        try (FileOutputStream out = new FileOutputStream(file, false)) { out.getFD().sync(); }
    }

    private void rotate() throws Exception {
        if (file.length() <= maxBytes) return;
        byte[] all = Files.readAllBytes(file.toPath());
        int start = Math.max(0, all.length - (int) maxBytes);
        while (start < all.length && all[start] != (byte) '\n') start++;
        if (start < all.length) start++;
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write(all, start, all.length - start);
            out.getFD().sync();
        }
    }

    private static String id(String value, String fallback) {
        String upper = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        return SAFE_ID.matcher(upper).matches() ? upper : fallback;
    }

    private static String safeText(String value, int limit) {
        String text = value == null ? "" : value.replaceAll("[\\r\\n\\[\\]]", "_").trim();
        return text.length() > limit ? text.substring(0, limit) : text;
    }

    static String sanitizeFields(String value) {
        if (value == null || value.isEmpty()) return "";
        List<String> kept = new ArrayList<>();
        for (String token : value.split("\\s+")) {
            int equals = token.indexOf('=');
            if (equals <= 0) continue;
            String key = token.substring(0, equals);
            if (sensitiveKey(key)) continue;
            String clean = LONG_SECRET.matcher(token).replaceAll("[REDACTED]").replaceAll("[\\r\\n]", "_");
            if (clean.length() > 160) clean = clean.substring(0, 160);
            kept.add(clean);
        }
        return String.join(" ", kept);
    }

    private static boolean sensitiveKey(String key) {
        String k = key.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        return k.contains("token") || k.contains("secret") || k.contains("nonce") || k.contains("hmac")
                || k.contains("authorization") || k.contains("qrpayload") || k.contains("proofjson")
                || k.equals("base64") || k.contains("rawpoint") || k.contains("coordinate")
                || k.contains("pngdata") || k.contains("workbookcontent");
    }

    public static final class Stats {
        public final int entries;
        public final long bytes;
        public final String lastEventAt;
        Stats(int entries, long bytes, String lastEventAt) { this.entries = entries; this.bytes = bytes; this.lastEventAt = lastEventAt; }
    }
}
