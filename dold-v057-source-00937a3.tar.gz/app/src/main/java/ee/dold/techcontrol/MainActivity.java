package ee.dold.techcontrol;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.SystemClock;
import android.provider.DocumentsContract;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.BarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1101;
    private static final int CAMERA_PERMISSION_REQUEST = 1102;
    private static final int EXPORT_DOCUMENT_REQUEST = 1103;
    private WorkspaceStore workspaceStore;
    private SignatureDraftStore signatureDraftStore;
    private DiagnosticLogStore diagnosticLogStore;
    private SignatureCaptureDialog signatureCaptureDialog;
    private LanSyncTransport lanSyncTransport;
    private final Map<String,LanDigestState> lanDigests = new ConcurrentHashMap<>();
    private boolean darkTheme = false;
    private volatile String lastCameraId;
    private volatile long lastCameraAt;
    private Uri importUri;
    private boolean exportWaiting = false;
    private final ExecutorService exportWorker = Executors.newSingleThreadExecutor();

    private FrameLayout rootLayout;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private FrameLayout scannerOverlay;
    private BarcodeView barcodeView;
    private boolean scannerActive = false;

    private File pendingExportFile;
    private FileOutputStream pendingExportStream;
    private String pendingExportName;
    private String pendingExportMime;
    private File pendingShareFile;
    private FileOutputStream pendingShareStream;
    private String pendingShareMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        workspaceStore = new WorkspaceStore(getFilesDir());
        signatureDraftStore = new SignatureDraftStore(getFilesDir());
        diagnosticLogStore = new DiagnosticLogStore(getFilesDir());
        appendDiagnostic("INFO", "APP", "STARTUP", "package=" + getPackageName() + " androidApi=" + Build.VERSION.SDK_INT);
        lanSyncTransport = new LanSyncTransport();
        String savedUri = getPreferences(MODE_PRIVATE).getString("importUri", null);
        if (savedUri != null) importUri = Uri.parse(savedUri);
        setLightSystemBars();

        rootLayout = new FrameLayout(this);
        webView = new WebView(this);
        // Keep the known-working v0.5.2 startup path. The v0.5.3 inset listener
        // ran during onCreate before WebView loaded and could terminate the
        // Activity on Android 16. Safe-area handling is intentionally isolated
        // from startup until it can be verified on a real device.
        if (Build.VERSION.SDK_INT >= 35) {
            webView.setPadding(0, getStatusBarHeight(), 0, 0);
        }
        rootLayout.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        setContentView(rootLayout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(false);
        settings.setUseWideViewPort(false);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                // Native storage/QR bridge is only available to our packaged UI.
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallbackNew,
                    FileChooserParams fileChooserParams
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackNew;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.dold.techcontrol.workpackage", "application/vnd.dold.techcontrol.syncpackage", "application/zip", "application/octet-stream", "image/*"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                if (importUri != null) intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, importUri);

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Failivalijat ei saanud avada", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void setLightSystemBars() {
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(
                    ViewGroup.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            );
        }
    }

    private int getStatusBarHeight() {
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return getResources().getDimensionPixelSize(resourceId);
        }
        return dp(28);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private SignatureCaptureCore.DeviceInfo signatureDeviceInfo(String deviceInstanceId) throws Exception {
        PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
        long versionCode = Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
        return new SignatureCaptureCore.DeviceInfo(deviceInstanceId, info.versionName, versionCode,
                Build.VERSION.RELEASE, Build.VERSION.SDK_INT);
    }

    private void showSignatureCapture(SignatureCaptureCore.Target target, SignatureCaptureCore.DeviceInfo device) {
        if (signatureCaptureDialog != null && signatureCaptureDialog.isShowing()) {
            sendSignatureCaptureError("Allkirjastamise aken on juba avatud.");
            return;
        }
        try {
            signatureCaptureDialog = new SignatureCaptureDialog(this, signatureDraftStore, target, device,
                    new SignatureCaptureDialog.Listener() {
                        @Override public void onDraftSaved(SignatureCaptureCore.Draft draft) {
                            JSONObject summary = signatureDraftSummary(draft);
                            Toast.makeText(MainActivity.this,
                                    "Allkirja andmed salvestati telefoni.", Toast.LENGTH_LONG).show();
                            sendSignatureCaptureSaved(summary.toString());
                            signatureCaptureDialog = null;
                        }
                        @Override public void onCaptureCancelled(String reason) {
                            if (reason != null && reason.contains("suurus muutus")) Toast.makeText(MainActivity.this, reason, Toast.LENGTH_LONG).show();
                            sendSignatureCaptureCancelled(reason);
                            signatureCaptureDialog = null;
                        }
                    });
            signatureCaptureDialog.show();
        } catch (Exception e) {
            signatureCaptureDialog = null;
            sendSignatureCaptureError(e.getMessage() == null ? "Allkirjastamist ei saanud avada." : e.getMessage());
        }
    }

    private JSONObject signatureDraftSummary(SignatureCaptureCore.Draft draft) {
        JSONObject out = new JSONObject();
        try {
            out.put("schemaVersion", draft.schemaVersion);
            out.put("status", draft.status);
            out.put("signatureId", draft.signatureId);
            out.put("nonce", draft.nonce);
            out.put("targetType", draft.targetType);
            out.put("recordId", draft.recordId);
            out.put("recordVersion", draft.recordVersion == null ? JSONObject.NULL : draft.recordVersion);
            out.put("recordVersionSource", draft.recordVersionSource);
            out.put("kilpId", draft.kilpId);
            out.put("signerName", draft.signerName);
            out.put("captureStartedAtUtcMs", draft.captureStartedAtUtcMs);
            out.put("captureEndedAtUtcMs", draft.captureEndedAtUtcMs);
            out.put("captureDurationMs", draft.captureDurationMs);
            out.put("clockSource", draft.clockSource);
            out.put("inputMethod", draft.inputMethod);
            out.put("strokeCount", draft.strokeCount);
            out.put("pointCount", draft.pointCount);
            out.put("canvasWidthPx", draft.canvasWidthPx);
            out.put("canvasHeightPx", draft.canvasHeightPx);
            out.put("pngHash", draft.pngHash);
            out.put("strokeHash", draft.strokeHash);
            out.put("geometryHash", draft.geometryHash);
            out.put("rendererProfile", draft.rendererProfile);
            out.put("deviceInstanceId", draft.deviceInstanceId);
            out.put("appVersionName", draft.appVersionName);
            out.put("appVersionCode", draft.appVersionCode);
            out.put("androidRelease", draft.androidRelease);
            out.put("androidApiLevel", draft.androidApiLevel);
            out.put("antiReuse", new JSONObject().put("algorithm", SignatureCaptureCore.ANTI_REUSE_ALGORITHM)
                    .put("result", draft.antiReuseResult).put("scope", draft.antiReuseScope)
                    .put("checkedAtUtcMs", draft.antiReuseCheckedAtUtcMs)
                    .put("checkedCount", draft.antiReuseCheckedCount)
                    .put("registryDigest", draft.antiReuseRegistryDigest)
                    .put("matchingSignatureIds", new org.json.JSONArray(draft.antiReuseMatchingSignatureIds))
                    .put("geometryHash", draft.geometryHash));
        } catch (Exception ignored) { }
        return out;
    }

    private JSONObject signatureDraftPayload(SignatureCaptureCore.Draft draft) throws Exception {
        JSONObject out = signatureDraftSummary(draft);
        JSONObject metadata = new JSONObject();
        for (Map.Entry<String, String> entry : draft.targetMetadata.entrySet()) metadata.put(entry.getKey(), entry.getValue());
        out.put("targetMetadata", metadata);
        org.json.JSONArray points = new org.json.JSONArray();
        for (SignatureCaptureCore.Point point : draft.points) {
            org.json.JSONArray tuple = new org.json.JSONArray();
            tuple.put(point.strokeNr).put(point.pointNr).put(point.xNorm).put(point.yNorm).put(point.elapsedMs);
            points.put(tuple);
        }
        out.put("points", points);
        out.put("pngBase64", Base64.encodeToString(draft.pngBytes, Base64.NO_WRAP));
        return out;
    }

    private void validateProductionDraftPng(SignatureCaptureCore.Draft draft) throws Exception {
        if (!SignaturePngRenderer.isSupportedProductionProfile(draft.rendererProfile))
            throw new IllegalStateException("Selle allkirja renderdusprofiil ei sobi tootmiskinnituseks.");
        Bitmap bitmap = BitmapFactory.decodeByteArray(draft.pngBytes, 0, draft.pngBytes.length);
        if (bitmap == null) throw new IllegalStateException("Allkirja PNG-faili ei saa dekodeerida.");
        try {
            if (bitmap.getWidth() != 900 || bitmap.getHeight() != 300)
                throw new IllegalStateException("Allkirja PNG mõõtmed ei vasta kinnitatud profiilile.");
            int[] pixels = new int[bitmap.getWidth() * bitmap.getHeight()];
            bitmap.getPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
            boolean ink = false;
            for (int pixel : pixels) if (Color.alpha(pixel) > 0) { ink = true; break; }
            if (!ink) throw new IllegalStateException("Allkirja PNG on tühi.");
        } finally { bitmap.recycle(); }
    }

    private void sendSignatureCaptureSaved(String json) {
        if (webView == null) return;
        String quoted = JSONObject.quote(json == null ? "{}" : json);
        runOnUiThread(() -> webView.evaluateJavascript("window.onNativeSignatureDraftSaved&&window.onNativeSignatureDraftSaved(" + quoted + ")", null));
    }

    private void sendSignatureCaptureCancelled(String reason) {
        if (webView == null) return;
        String quoted = JSONObject.quote(reason == null ? "" : reason);
        runOnUiThread(() -> webView.evaluateJavascript("window.onNativeSignatureCaptureCancelled&&window.onNativeSignatureCaptureCancelled(" + quoted + ")", null));
    }

    private void sendSignatureCaptureError(String message) {
        String safe = message == null ? "Allkirjastamist ei saanud alustada." : message;
        Toast.makeText(this, safe, Toast.LENGTH_LONG).show();
        if (webView == null) return;
        String quoted = JSONObject.quote(safe);
        runOnUiThread(() -> webView.evaluateJavascript("window.onNativeSignatureCaptureError&&window.onNativeSignatureCaptureError(" + quoted + ")", null));
    }


    /**
     * QR camera is rendered inside this Activity as an overlay over the WebView.
     * This avoids switching to another scanner Activity / external app.
     */
    private void showQrScanner() {
        if (scannerActive || rootLayout == null) return;

        scannerActive = true;
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(0);
        }

        scannerOverlay = new FrameLayout(this);
        scannerOverlay.setBackgroundColor(Color.BLACK);

        barcodeView = new BarcodeView(this);
        barcodeView.setDecoderFactory(new DefaultDecoderFactory(
                Collections.singletonList(BarcodeFormat.QR_CODE)
        ));
        scannerOverlay.addView(barcodeView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        // Simple scan frame. It is only a visual guide; the decoder scans the full preview.
        FrameLayout scanFrame = new FrameLayout(this);
        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setColor(Color.TRANSPARENT);
        frameBg.setStroke(dp(3), Color.WHITE);
        frameBg.setCornerRadius(dp(14));
        scanFrame.setBackground(frameBg);
        FrameLayout.LayoutParams frameParams = new FrameLayout.LayoutParams(dp(260), dp(260));
        frameParams.gravity = Gravity.CENTER;
        scannerOverlay.addView(scanFrame, frameParams);

        TextView prompt = new TextView(this);
        prompt.setText("Skaneeri elektrikilbi QR-kood");
        prompt.setTextColor(Color.WHITE);
        prompt.setTextSize(19);
        prompt.setGravity(Gravity.CENTER);
        prompt.setPadding(dp(16), dp(16), dp(16), dp(16));
        FrameLayout.LayoutParams promptParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        promptParams.gravity = Gravity.TOP;
        promptParams.topMargin = dp(24);
        promptParams.leftMargin = dp(20);
        promptParams.rightMargin = dp(20);
        scannerOverlay.addView(prompt, promptParams);

        Button cancel = new Button(this);
        cancel.setText("TÜHISTA");
        cancel.setTextSize(16);
        cancel.setOnClickListener(v -> closeQrScanner(false));
        FrameLayout.LayoutParams cancelParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        cancelParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        cancelParams.bottomMargin = dp(32);
        scannerOverlay.addView(cancel, cancelParams);

        rootLayout.addView(scannerOverlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        BarcodeCallback callback = new BarcodeCallback() {
            @Override
            public void barcodeResult(BarcodeResult result) {
                if (!scannerActive || result == null || result.getText() == null || result.getText().trim().isEmpty()) {
                    return;
                }
                String text = result.getText();
                java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("\\bEK-\\d{3,}\\b").matcher(text.toUpperCase(java.util.Locale.ROOT));
                lastCameraId = matcher.find() ? matcher.group() : null;
                lastCameraAt = SystemClock.elapsedRealtime();
                runOnUiThread(() -> {
                    closeQrScanner(true);
                    sendQrResultToWeb(text);
                });
            }

            @Override
            public void possibleResultPoints(List<ResultPoint> resultPoints) {
                // No UI action needed.
            }
        };

        barcodeView.decodeSingle(callback);
        barcodeView.resume();
    }

    private void closeQrScanner(boolean success) {
        if (!scannerActive && scannerOverlay == null) return;

        scannerActive = false;
        try {
            if (barcodeView != null) barcodeView.pause();
        } catch (Exception ignored) {
        }

        if (rootLayout != null && scannerOverlay != null) {
            rootLayout.removeView(scannerOverlay);
        }
        barcodeView = null;
        scannerOverlay = null;
        setLightSystemBars();

        if (!success) {
            // Cancellation is normal. Do not show an error toast.
        }
    }

    private void requestOrLaunchQrScanner() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST
            );
        } else {
            showQrScanner();
        }
    }

    private void sendQrResultToWeb(String value) {
        if (value == null) return;
        String js = "window.onNativeQrResult(" + JSONObject.quote(value) + ");";
        webView.evaluateJavascript(js, null);
    }

    private void sendQrErrorToWeb(String value) {
        String js = "window.onNativeQrError(" + JSONObject.quote(value == null ? "" : value) + ");";
        webView.evaluateJavascript(js, null);
    }

    private void sendExportResult(boolean ok, String message) {
        runOnUiThread(() -> {
            String js = "window.onNativeExportFinished(" + (ok ? "true" : "false") + "," +
                    JSONObject.quote(message == null ? "" : message) + ");";
            webView.evaluateJavascript(js, null);
        });
    }

    private void sendShareResult(boolean ok, String message) {
        runOnUiThread(() -> {
            String js = "window.onNativeShareFinished(" + (ok ? "true" : "false") + "," +
                    JSONObject.quote(message == null ? "" : message) + ");";
            webView.evaluateJavascript(js, null);
        });
    }

    private synchronized boolean beginShare(String fileName, String mime) {
        try {
            closePendingShareQuietly();
            File directory = new File(getCacheDir(), "shared");
            if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("Jagamise kausta ei saa luua");
            String safeName = sanitizeShareFileName(fileName);
            pendingShareFile = new File(directory, "share_" + System.currentTimeMillis() + "_" + safeName);
            pendingShareMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            pendingShareStream = new FileOutputStream(pendingShareFile);
            return true;
        } catch (Exception e) {
            closePendingShareQuietly();
            sendShareResult(false, e.getMessage());
            return false;
        }
    }

    private synchronized boolean appendShareChunk(String base64Chunk) {
        try {
            if (pendingShareStream == null) throw new IllegalStateException("Jagatav fail pole ette valmistatud");
            pendingShareStream.write(Base64.decode(base64Chunk, Base64.DEFAULT));
            return true;
        } catch (Exception e) {
            closePendingShareQuietly();
            sendShareResult(false, e.getMessage());
            return false;
        }
    }

    private synchronized boolean finishShare() {
        try {
            if (pendingShareStream == null || pendingShareFile == null) throw new IllegalStateException("Jagatav fail puudub");
            pendingShareStream.flush(); pendingShareStream.getFD().sync(); pendingShareStream.close(); pendingShareStream = null;
            final File file = pendingShareFile;
            final String mime = pendingShareMime;
            pendingShareFile = null; pendingShareMime = null;
            runOnUiThread(() -> {
                try {
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mime); send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.setClipData(ClipData.newUri(getContentResolver(), "DOLD TechControl package", uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(send, "Jaga DOLD TechControli tööfaili");
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(chooser);
                    sendShareResult(true, "Androidi jagamismenüü avati");
                } catch (Exception e) {
                    sendShareResult(false, e.getMessage());
                }
            });
            return true;
        } catch (Exception e) {
            closePendingShareQuietly();
            sendShareResult(false, e.getMessage());
            return false;
        }
    }

    private synchronized void closePendingShareQuietly() {
        try { if (pendingShareStream != null) pendingShareStream.close(); } catch (Exception ignored) {}
        pendingShareStream = null;
        if (pendingShareFile != null && pendingShareFile.exists()) pendingShareFile.delete();
        pendingShareFile = null; pendingShareMime = null;
    }

    private String sanitizeShareFileName(String name) {
        String safe = name == null ? "DOLD_TechControl.xlsx" : name;
        safe = safe.replaceAll("[\\\\/:*?\"<>|]", "_");
        return safe.isEmpty() ? "DOLD_TechControl.xlsx" : safe;
    }

    private synchronized void beginExport(String fileName, String mime) throws Exception {
        if (exportWaiting) throw new IllegalStateException("Eksport on juba pooleli");
        closePendingExportQuietly();

        pendingExportName = sanitizeFileName(fileName);
        pendingExportMime = (mime == null || mime.isEmpty())
                ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                : mime;

        pendingExportFile = new File(getCacheDir(), "export_" + System.currentTimeMillis() + ".tmp");
        pendingExportStream = new FileOutputStream(pendingExportFile);
    }

    private synchronized void appendExportChunk(String base64Chunk) throws Exception {
        if (pendingExportStream == null) {
            throw new IllegalStateException("Export is not started");
        }
        byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
        pendingExportStream.write(bytes);
    }

    private synchronized void finishExport() {
        try {
            if (pendingExportStream == null) throw new IllegalStateException("Eksport ei ole alustatud");
            pendingExportStream.flush();pendingExportStream.getFD().sync();pendingExportStream.close();pendingExportStream=null;
            exportWaiting=true;
            runOnUiThread(() -> {
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(pendingExportMime);
                intent.putExtra(Intent.EXTRA_TITLE,pendingExportName);
                // A document URI makes the picker start in its parent when supported.
                // OPEN_DOCUMENT grants access to one file, never permission to invent a parent URI.
                if(importUri!=null)intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI,importUri);
                try { startActivityForResult(intent,EXPORT_DOCUMENT_REQUEST); }
                catch(Exception e) { exportWorker.execute(this::exportToDownloads); }
            });
        } catch(Exception e) {closePendingExportQuietly();sendExportResult(false,e.getMessage());}
    }

    private synchronized void writeExportDocument(Uri destination) {
        try {
            if(destination==null || pendingExportFile==null)throw new IllegalStateException("Ekspordi siht puudub");
            if(destination.equals(importUri))throw new IllegalStateException("Algfaili üle kirjutamine on keelatud");
            try(FileInputStream in=new FileInputStream(pendingExportFile);OutputStream out=getContentResolver().openOutputStream(destination,"w")){
                if(out==null)throw new IllegalStateException("Sihtfaili ei saa avada");
                byte[] buf=new byte[65536];int count;while((count=in.read(buf))!=-1)out.write(buf,0,count);out.flush();
            }
            String name=pendingExportName,mime=pendingExportMime;closePendingExportQuietly();sendExportResult(true,("text/plain".equals(mime)?"Diagnostika logi salvestatud: ":"XLSX koopia salvestatud: ")+name);
        }catch(Exception e){closePendingExportQuietly();sendExportResult(false,e.getMessage());}
    }

    private synchronized void exportToDownloads() {
        try {
            if (pendingExportFile == null) throw new IllegalStateException("Export is not started");

            String destination;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingExportName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, pendingExportMime);
                values.put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Kilbikontroll"
                );
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                Uri uri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        values
                );
                if (uri == null) {
                    throw new IllegalStateException("Downloads faili ei saanud luua");
                }

                try (FileInputStream in = new FileInputStream(pendingExportFile);
                     OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) {
                        throw new IllegalStateException("Downloads faili ei saanud avada");
                    }
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                }

                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
                destination = "Downloads/Kilbikontroll/" + pendingExportName;
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) {
                    throw new IllegalStateException("Downloads kaust pole saadaval");
                }
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new IllegalStateException("Downloads kausta ei saanud luua");
                }
                File outFile = new File(dir, pendingExportName);
                try (FileInputStream in = new FileInputStream(pendingExportFile);
                     FileOutputStream out = new FileOutputStream(outFile)) {
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                }
                destination = outFile.getAbsolutePath();
            }

            if (pendingExportFile.exists()) {
                pendingExportFile.delete();
            }

            String completedMime = pendingExportMime;
            pendingExportFile = null;
            pendingExportName = null;
            pendingExportMime = null;

            exportWaiting=false;
            sendExportResult(true, "Failivalija puudus. " + ("text/plain".equals(completedMime) ? "Diagnostika logi" : "XLSX") + " salvestatud: " + destination);
        } catch (Exception e) {
            closePendingExportQuietly();
            sendExportResult(false, e.getMessage());
        }
    }

    private synchronized void closePendingExportQuietly() {
        exportWaiting=false;
        try {
            if (pendingExportStream != null) {
                pendingExportStream.close();
            }
        } catch (Exception ignored) {
        }
        pendingExportStream = null;

        if (pendingExportFile != null && pendingExportFile.exists()) {
            pendingExportFile.delete();
        }
        pendingExportFile = null;
    }

    private String sanitizeFileName(String name) {
        String safe = name == null ? "Kilbikontroll.xlsx" : name;
        safe = safe.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!safe.toLowerCase().endsWith(".xlsx")) {
            safe += ".xlsx";
        }
        return safe;
    }

    public class AndroidBridge {
        @JavascriptInterface public void appendDiagnosticLog(String level,String component,String event,String fieldsJson){
            try {
                JSONObject values=fieldsJson==null?new JSONObject():new JSONObject(fieldsJson);StringBuilder fields=new StringBuilder();
                java.util.Iterator<String> keys=values.keys();while(keys.hasNext()){String key=keys.next();Object value=values.opt(key);
                    if(value==null||value==JSONObject.NULL||value instanceof JSONObject||value instanceof org.json.JSONArray)continue;
                    String text=String.valueOf(value).replaceAll("[\\r\\n\\t ]+","_");if(text.length()>160)text=text.substring(0,160);
                    if(fields.length()>0)fields.append(' ');fields.append(key.replaceAll("[^A-Za-z0-9_]","_")).append('=').append(text);
                }
                appendDiagnostic(level,component,event,fields.toString());
            }catch(Exception ignored){}
        }
        @JavascriptInterface public String readDiagnosticLog(){try{return diagnosticLogStore==null?"":diagnosticLogStore.read();}catch(Exception e){return "";}}
        @JavascriptInterface public String getDiagnosticLogStats(){
            try{DiagnosticLogStore.Stats stats=diagnosticLogStore.stats();JSONObject out=new JSONObject();out.put("entries",stats.entries);out.put("bytes",stats.bytes);out.put("lastEventAt",stats.lastEventAt);return out.toString();}
            catch(Exception e){return "{\"entries\":0,\"bytes\":0,\"lastEventAt\":\"\"}";}
        }
        @JavascriptInterface public boolean clearDiagnosticLog(){try{diagnosticLogStore.clear();return true;}catch(Exception e){return false;}}
        @JavascriptInterface public boolean copyDiagnosticText(String text){
            if(text==null||text.length()>512*1024)return false;
            try{ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);if(clipboard==null)return false;clipboard.setPrimaryClip(ClipData.newPlainText("DOLD TechControl diagnostic log",text));return true;}catch(Exception e){return false;}
        }
        @JavascriptInterface public String getDiagnosticDeviceContext(){
            try{PackageInfo info=getPackageManager().getPackageInfo(getPackageName(),0);JSONObject out=new JSONObject();out.put("versionName",info.versionName);out.put("versionCode",Build.VERSION.SDK_INT>=28?info.getLongVersionCode():info.versionCode);out.put("package",getPackageName());out.put("androidVersion",Build.VERSION.RELEASE);out.put("api",Build.VERSION.SDK_INT);out.put("manufacturer",Build.MANUFACTURER);out.put("model",Build.MODEL);return out.toString();}
            catch(Exception e){return "{}";}
        }
        @JavascriptInterface public void beginDiagnosticExport(){
            try{synchronized(MainActivity.this){if(exportWaiting)throw new IllegalStateException("Eksport on juba pooleli");closePendingExportQuietly();pendingExportName="DOLD_TechControl_log.txt";pendingExportMime="text/plain";pendingExportFile=new File(getCacheDir(),"diagnostic_"+System.currentTimeMillis()+".tmp");pendingExportStream=new FileOutputStream(pendingExportFile);}}
            catch(Exception e){sendExportResult(false,e.getMessage());}
        }
        @JavascriptInterface public String saveWorkspace(String id,String payload){try{workspaceStore.save(id,payload);return WorkspaceStore.ok(true);}catch(Exception e){return WorkspaceStore.error(e);}}
        @JavascriptInterface public String readWorkspace(String id){try{return WorkspaceStore.ok(workspaceStore.read(id));}catch(Exception e){return WorkspaceStore.error(e);}}
        @JavascriptInterface public String listWorkspaces(){try{return WorkspaceStore.ok(workspaceStore.list());}catch(Exception e){return WorkspaceStore.error(e);}}
        @JavascriptInterface public String listWorkspaceErrors(){try{return WorkspaceStore.ok(workspaceStore.listErrors());}catch(Exception e){return WorkspaceStore.error(e);}}
        @JavascriptInterface public String hashBytes(String base64){try{return WorkspaceStore.hash(Base64.decode(base64,Base64.DEFAULT));}catch(Exception e){throw new IllegalStateException(e);}}
        @JavascriptInterface public String beginLanPackageDigest(){
            try{String id=UUID.randomUUID().toString().replace("-","");lanDigests.put(id,new LanDigestState(MessageDigest.getInstance("SHA-256")));return id;}
            catch(NoSuchAlgorithmException e){throw new IllegalStateException("SHA-256 is unavailable",e);}
        }
        @JavascriptInterface public boolean updateLanPackageDigest(String id,String base64Chunk){
            LanDigestState state=lanDigests.get(id);if(state==null||base64Chunk==null||base64Chunk.length()>((LanSyncTransport.MAX_PAYLOAD_BYTES+2L)/3L)*4L+8L)return false;
            try{byte[] bytes=Base64.decode(base64Chunk,Base64.DEFAULT);if(bytes.length>LanSyncTransport.MAX_PAYLOAD_BYTES||state.total+bytes.length>100L*1024L*1024L)return false;synchronized(state){state.digest.update(bytes);state.total+=bytes.length;}return true;}
            catch(Exception e){return false;}
        }
        @JavascriptInterface public String finishLanPackageDigest(String id){
            LanDigestState state=lanDigests.remove(id);if(state==null)return "";
            synchronized(state){byte[] hash=state.digest.digest();StringBuilder out=new StringBuilder(hash.length*2);for(byte b:hash)out.append(String.format(java.util.Locale.ROOT,"%02x",b&0xff));return out.toString();}
        }
        @JavascriptInterface public void cancelLanPackageDigest(String id){if(id!=null)lanDigests.remove(id);}
        @JavascriptInterface public boolean startSignatureCapture(String targetJson){
            try {
                if(targetJson==null||targetJson.length()>16_384)throw new IllegalArgumentException("Allkirja sihtandmed on vigased");
                JSONObject value=new JSONObject(targetJson);
                Object rawVersion=value.opt("recordVersion");Long recordVersion=null;
                if(rawVersion instanceof Number){double numeric=((Number)rawVersion).doubleValue();if(Double.isFinite(numeric)&&numeric>=0&&numeric==Math.rint(numeric)&&numeric<=Long.MAX_VALUE)recordVersion=(long)numeric;}
                JSONObject metadata=value.optJSONObject("metadata");Map<String,String> metadataValues=new HashMap<>();
                if(metadata!=null){java.util.Iterator<String> keys=metadata.keys();while(keys.hasNext()){String key=keys.next();Object item=metadata.opt(key);if(item instanceof String||item instanceof Number||item instanceof Boolean)metadataValues.put(key,String.valueOf(item));}}
                SignatureCaptureCore.Target target=new SignatureCaptureCore.Target(
                        value.optString("targetType",""),value.optString("recordId",""),value.optString("kilpId",""),
                        value.optString("signerName",""),recordVersion,value.optString("recordVersionSource","UNRESOLVED"),metadataValues);
                SignatureCaptureCore.DeviceInfo device=signatureDeviceInfo(value.optString("deviceInstanceId",""));
                runOnUiThread(()->showSignatureCapture(target,device));
                return true;
            } catch(Exception e) {
                runOnUiThread(()->sendSignatureCaptureError(e.getMessage()==null?"Allkirja sihtandmed on vigased":e.getMessage()));
                return false;
            }
        }
        @JavascriptInterface public String listSignatureDrafts(){
            try{org.json.JSONArray result=new org.json.JSONArray();for(SignatureCaptureCore.Draft draft:signatureDraftStore.listDrafts())result.put(signatureDraftSummary(draft));return WorkspaceStore.ok(result);}
            catch(Exception e){return WorkspaceStore.error(e);}
        }
        @JavascriptInterface public String readSignatureDraft(String signatureId){
            try{
                if(signatureId==null||signatureId.length()>64)throw new IllegalArgumentException("AllkiriID on vigane");
                SignatureCaptureCore.Draft draft=signatureDraftStore.readDraftById(signatureId);
                validateProductionDraftPng(draft);
                return WorkspaceStore.ok(signatureDraftPayload(draft));
            }catch(Exception e){return WorkspaceStore.error(e);}
        }
        @JavascriptInterface public String startLanSyncSession(String dbId,String responseBase64){
            try {
                byte[] response=decodeLanPayload(responseBase64);
                return lanSyncTransport.startHost(dbId,response).toJson();
            } catch(Exception e) { return lanErrorJson("INVALID_PAYLOAD","LAN payload could not be prepared."); }
        }
        @JavascriptInterface public String startLanSyncSessionDeferred(String dbId,String initialResponseBase64){
            try {
                byte[] initialResponse=decodeLanPayload(initialResponseBase64);
                return lanSyncTransport.startHostDeferred(dbId,initialResponse).toJson();
            } catch(Exception e) { return lanErrorJson("INVALID_PAYLOAD","LAN payload could not be prepared."); }
        }
        @JavascriptInterface public String startLanSyncSessionChunked(String dbId){
            try { return lanSyncTransport.startHostChunkedDeferred(dbId).toJson(); }
            catch(Exception e) { return lanErrorJson("HOST_UNAVAILABLE","Temporary LAN session could not be started."); }
        }
        @JavascriptInterface public boolean respondLanSyncSession(String responseBase64,boolean terminal){
            try { return lanSyncTransport!=null&&lanSyncTransport.respondHost(decodeLanPayload(responseBase64),terminal); }
            catch(Exception e) { return false; }
        }
        @JavascriptInterface public boolean stopLanSyncSession(){return lanSyncTransport!=null&&lanSyncTransport.stopHost();}
        @JavascriptInterface public boolean stopLanSyncSessionFor(String sessionId){return lanSyncTransport!=null&&lanSyncTransport.stopHostForSession(sessionId);}
        @JavascriptInterface public String getLanSyncSessionStatus(){
            try {
                LanSyncTransport.HostStatus status=lanSyncTransport.getHostStatus();
                JSONObject out=new JSONObject();out.put("status",status.status);out.put("error",status.error);
                if(status.pairing!=null){out.put("expiresAt",status.pairing.expiresAt);out.put("sessionId",status.pairing.sessionId);}
                if(status.receivedPayload!=null&&("REQUEST_RECEIVED".equals(status.status)||"ACK_RECEIVED".equals(status.status)||"COMPLETED".equals(status.status)))out.put("requestBase64",Base64.encodeToString(status.receivedPayload,Base64.NO_WRAP));
                return out.toString();
            } catch(Exception e) { return lanErrorJson("STATUS_UNAVAILABLE","Session status is unavailable."); }
        }
        @JavascriptInterface public String startLanSyncClient(String pairingJson,String expectedDbId,String requestBase64){
            try {
                if(pairingJson==null||pairingJson.length()>2048)return lanErrorJson("MALFORMED_PAIRING","Pairing information is invalid.");
                JSONObject p=new JSONObject(pairingJson);
                LanSyncTransport.PairingInfo info=new LanSyncTransport.PairingInfo(
                        p.optInt("protocol",-1),p.optString("host",""),p.optInt("port",-1),
                        p.optString("sessionId",""),p.optString("token",""),p.optLong("createdAt",0),
                        p.optLong("expiresAt",0),p.optString("lineage",""));
                byte[] request=decodeLanPayload(requestBase64);
                LanSyncTransport.ClientJob job=lanSyncTransport.startClient(info,expectedDbId,request);
                JSONObject out=new JSONObject();out.put("ok",true);out.put("jobId",job.id);out.put("status",job.getState());return out.toString();
            } catch(Exception e) { return lanErrorJson("MALFORMED_PAIRING","Pairing information or payload is invalid."); }
        }
        @JavascriptInterface public String getLanSyncClientResult(String jobId){
            try {
                LanSyncTransport.ClientJob job=lanSyncTransport.getClientJob(jobId);
                if(job==null)return lanErrorJson("UNKNOWN_JOB","LAN connection job was not found.");
                JSONObject out=new JSONObject();out.put("jobId",job.id);out.put("status",job.getState());
                LanSyncTransport.ClientResult result=job.getResult();
                if(result!=null){out.put("result",result.status);if(result.isSuccess())out.put("responseBase64",Base64.encodeToString(result.payload,Base64.NO_WRAP));lanSyncTransport.consumeClientJob(jobId);}
                return out.toString();
            } catch(Exception e) { return lanErrorJson("RESULT_UNAVAILABLE","LAN result is unavailable."); }
        }
        @JavascriptInterface public String createLanSyncQrPngBase64(String payload,int size){
            if(payload==null||payload.length()>2048||!payload.startsWith("DOLD-DIRECT-SYNC/1:")||size<320||size>1024)return "";
            Bitmap bitmap=null;
            try {
                Map<EncodeHintType,Object> hints=new HashMap<>();
                hints.put(EncodeHintType.MARGIN,4);
                hints.put(EncodeHintType.ERROR_CORRECTION,ErrorCorrectionLevel.M);
                com.google.zxing.common.BitMatrix matrix=new QRCodeWriter().encode(payload,BarcodeFormat.QR_CODE,size,size,hints);
                int width=matrix.getWidth(),height=matrix.getHeight();int[] pixels=new int[width*height];
                for(int y=0;y<height;y++)for(int x=0;x<width;x++)pixels[y*width+x]=matrix.get(x,y)?Color.BLACK:Color.WHITE;
                bitmap=Bitmap.createBitmap(pixels,width,height,Bitmap.Config.ARGB_8888);
                ByteArrayOutputStream output=new ByteArrayOutputStream();
                if(!bitmap.compress(Bitmap.CompressFormat.PNG,100,output))return "";
                return Base64.encodeToString(output.toByteArray(),Base64.NO_WRAP);
            } catch(Exception e) { return ""; }
            finally { if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle(); }
        }
        @JavascriptInterface public long elapsedRealtime(){return SystemClock.elapsedRealtime();}
        @JavascriptInterface public void setTheme(boolean dark){runOnUiThread(()->{darkTheme=dark;if(!scannerActive)setLightSystemBars();});}
        @JavascriptInterface public boolean beginShareFile(String fileName,String mime){return beginShare(fileName,mime);}
        @JavascriptInterface public boolean writeShareChunk(String base64Chunk){return appendShareChunk(base64Chunk);}
        @JavascriptInterface public boolean finishShareFile(){return finishShare();}
        @JavascriptInterface public synchronized boolean consumeQrProof(String id){
            boolean valid=id!=null&&id.equals(lastCameraId)&&SystemClock.elapsedRealtime()-lastCameraAt<120000;
            lastCameraId=null;return valid;
        }

        @JavascriptInterface
        public void scanQr() {
            runOnUiThread(MainActivity.this::requestOrLaunchQrScanner);
        }

        @JavascriptInterface
        public void beginSaveFile(String fileName, String mime) {
            try {
                beginExport(fileName, mime);
            } catch (Exception e) {
                sendExportResult(false, e.getMessage());
            }
        }

        @JavascriptInterface
        public void writeSaveChunk(String base64Chunk) {
            try {
                appendExportChunk(base64Chunk);
            } catch (Exception e) {
                sendExportResult(false, e.getMessage());
            }
        }

        @JavascriptInterface
        public void finishSaveFile() {
            finishExport();
        }

        @JavascriptInterface
        public String getAppVersion() {
            return "0.5.7";
        }
    }

    private byte[] decodeLanPayload(String base64) throws Exception {
        if(base64==null||base64.isEmpty())return new byte[0];
        if(base64.length()>((LanSyncTransport.MAX_PAYLOAD_BYTES+2L)/3L)*4L+8L)throw new IllegalArgumentException("Payload exceeds limit");
        byte[] decoded=Base64.decode(base64,Base64.NO_WRAP);
        if(decoded.length>LanSyncTransport.MAX_PAYLOAD_BYTES)throw new IllegalArgumentException("Payload exceeds limit");
        return decoded;
    }

    private void appendDiagnostic(String level,String component,String event,String fields){
        try{if(diagnosticLogStore==null)return;String timestamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.ROOT).format(new Date());diagnosticLogStore.append(timestamp,level,component,event,fields);}
        catch(Exception ignored){}
    }

    private String lanErrorJson(String status,String message){
        try {JSONObject out=new JSONObject();out.put("ok",false);out.put("status",status);out.put("message",message);return out.toString();}
        catch(Exception e){return "{\"ok\":false,\"status\":\"ERROR\"}";}
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==EXPORT_DOCUMENT_REQUEST){
            if(resultCode==Activity.RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();exportWorker.execute(()->writeExportDocument(uri));}
            else {closePendingExportQuietly();sendExportResult(false,"Eksport tühistatud");}
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                if(results!=null&&results.length>0){
                    Uri candidate=results[0];String mime=getContentResolver().getType(candidate);
                    if(mime==null||!mime.startsWith("image/")){
                        importUri=candidate;getPreferences(MODE_PRIVATE).edit().putString("importUri",candidate.toString()).commit();
                        try{getContentResolver().takePersistableUriPermission(candidate,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showQrScanner();
            } else {
                sendQrErrorToWeb("Kaamera luba puudub");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (scannerActive && barcodeView != null) {
            try {
                barcodeView.resume();
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    protected void onPause() {
        if (barcodeView != null) {
            try {
                barcodeView.pause();
            } catch (Exception ignored) {
            }
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (signatureCaptureDialog != null && signatureCaptureDialog.isShowing()) {
            signatureCaptureDialog.cancelFromLifecycle();
            signatureCaptureDialog = null;
            return;
        }
        if (scannerActive) {
            closeQrScanner(false);
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (signatureCaptureDialog != null) {
            signatureCaptureDialog.cancelFromLifecycle();
            signatureCaptureDialog = null;
        }
        closeQrScanner(false);
        closePendingExportQuietly();
        if(lanSyncTransport!=null)lanSyncTransport.close();
        lanDigests.clear();
        if (webView != null) {
            webView.destroy();
        }
        exportWorker.shutdown();
        super.onDestroy();
    }

    private static final class LanDigestState {
        final MessageDigest digest;
        long total;
        LanDigestState(MessageDigest digest){this.digest=digest;}
    }
}
