package ee.dold.techcontrol;

import java.io.File;
import java.nio.file.Files;

public final class DiagnosticLogStoreTest {
    private static int passed;
    private static void check(boolean value, String name) { if (!value) throw new AssertionError(name); passed++; System.out.println("PASS " + name); }
    public static void main(String[] args) throws Exception {
        File dir = Files.createTempDirectory("dold-diag").toFile();
        DiagnosticLogStore store = new DiagnosticLogStore(dir, 1400);
        store.append("2026-10-27 18:42:31.442", "INFO", "APP", "STARTUP", "revision=1");
        check(store.read().contains("[2026-10-27 18:42:31.442] INFO APP STARTUP revision=1"), "append format");
        store.append("2026-10-27 18:42:31.443", "WARN", "LAN", "CHUNK_RETRY", "attempt=2");
        check(store.read().indexOf("STARTUP") < store.read().indexOf("CHUNK_RETRY"), "timestamp ordering");
        DiagnosticLogStore restored = new DiagnosticLogStore(dir, 1400);
        check(restored.stats().entries == 2 && restored.read().contains("STARTUP"), "persistence after restart");
        for (int i = 0; i < 120; i++) restored.append("2026-10-27 18:42:32.000", "INFO", "LAN", "CHUNK_RX", "chunk=" + i + "/120 bytes=262144 attempt=1 status=OK");
        String rotated = restored.read();
        check(rotated.getBytes(java.nio.charset.StandardCharsets.UTF_8).length <= 1400 && !rotated.contains("STARTUP") && rotated.contains("chunk=119/120"), "bounded rotation");
        restored.append("2026-10-27 18:42:33.000", "ERROR", "LAN", "SHA_MISMATCH", "token=TOPSECRET hmac_key=BAD raw_points=1,2,3 proof_json=hidden png_data=hidden code=SHA_MISMATCH safe=value aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa=bad");
        String secured = restored.read();
        check(!secured.contains("TOPSECRET") && !secured.contains("hmac_key") && !secured.contains("raw_points") && !secured.contains("proof_json") && !secured.contains("png_data") && secured.contains("code=SHA_MISMATCH"), "secret filtering");
        restored.clear();
        restored.append("2026-10-27 18:42:34.000", "INFO", "APP", "LOG_CLEARED", "");
        check(restored.stats().entries == 1 && restored.read().contains("INFO APP LOG_CLEARED"), "clear marker");
        System.out.println("DiagnosticLogStore: " + passed + "/6 PASS");
    }
}
