const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'../..'),source=fs.readFileSync(path.join(root,'app/src/main/assets/DOLD_TechControl_v0.5.3.js'),'utf8');
const start=source.indexOf('const DIAGNOSTIC_SENSITIVE_KEY='),end=source.indexOf('const cloneData=',start);assert(start>=0&&end>start);
const emitted=[],copied=[],exported=[];let pending=null,toastText='',cleared=false;
const Android={
 appendDiagnosticLog(level,component,event,fields){const f=JSON.parse(fields);emitted.push({level,component,event,fields:f});},
 readDiagnosticLog(){return ['[2026-10-27 18:00:00.000] INFO APP STARTUP status=OK','[2026-10-27 18:00:01.000] WARN LAN CHUNK_RETRY transfer=abc chunk=2/7 attempt=2','[2026-10-27 18:00:02.000] ERROR LAN SHA_MISMATCH code=SHA_MISMATCH','[2026-10-27 18:00:03.000] INFO SYNC APPLY applied=4 duplicates=2 conflicts=0'].join('\n');},
 getDiagnosticLogStats(){return JSON.stringify({entries:4,bytes:420,lastEventAt:'2026-10-27 18:00:03.000'});},
 getDiagnosticDeviceContext(){return JSON.stringify({versionName:'0.5.7',versionCode:58,package:'ee.dold.techcontrol',androidVersion:'16',api:36,manufacturer:'OnePlus',model:'CPH2653'});},
 copyDiagnosticText(text){copied.push(text);return true;},clearDiagnosticLog(){cleared=true;return true;},
 beginDiagnosticExport(){pending=[];},writeSaveChunk(value){pending.push(Buffer.from(value,'base64'));},finishSaveFile(){exported.push(Buffer.concat(pending).toString('utf8'));pending=null;}
};
const elements={diagnosticStats:{textContent:''}};
const context={
 APP_VERSION:'0.5.7',
 TC:{deviceId:'device-0123456789abcdef0123456789abcdef',dbId:'database-0123456789abcdef',sync:{epoch:'epoch-0123456789abcdef'},revision:42},
 S:{fileName:'DOLD töö.xlsx'},Android,window:{Android},
 localStorage:{getItem(){return 'device-0123456789abcdef0123456789abcdef';}},
 Date,TextEncoder,Blob,URL,setTimeout(){},
 document:{createElement(){return {click(){},remove(){}}}},
 $:(id)=>elements[id]||null,toast:(v)=>{toastText=v;},showAppChoice:async()=> 'clear',
 bytesToBase64:(v)=>Buffer.from(v).toString('base64'),onNativeExportFinished:async()=>{}
};
context.window=context;vm.createContext(context);vm.runInContext(source.slice(start,end),context);
const tests=[];async function test(name,fn){try{await fn();tests.push(true);console.log('PASS',name);}catch(e){console.error('FAIL',name,e);process.exitCode=1;}}
(async()=>{
 await test('copy includes header, model and API',async()=>{await context.copyDiagnosticLog();assert.equal(toastText,'Diagnostika kopeeritud');const t=copied.at(-1);assert(t.includes('App version: 0.5.7'));assert(t.includes('Version code: 58'));assert(t.includes('Package: ee.dold.techcontrol'));assert(t.includes('Android: 16 (API 36)'));assert(t.includes('Device: OnePlus CPH2653'));assert(t.includes('Workbook revision: 42'));});
 await test('copy retains recent error and context',async()=>{const t=copied.at(-1);assert(t.includes('CHUNK_RETRY'));assert(t.includes('ERROR LAN SHA_MISMATCH'));});
 await test('export produces exact txt name payload',async()=>{await context.exportDiagnosticLog();assert.equal(exported.length,1);assert(exported[0].startsWith('DOLD TechControl diagnostic log'));assert(emitted.some(x=>x.event==='DIAGNOSTIC_EXPORT_START'&&x.fields.filename==='DOLD_TechControl_log.txt'));});
 await test('clear confirms and creates marker',async()=>{await context.clearDiagnosticLog();assert(cleared);assert(emitted.some(x=>x.level==='INFO'&&x.component==='APP'&&x.event==='LOG_CLEARED'));});
 await test('ERROR machine code is retained',async()=>{context.diagLog('ERROR','LAN','SHA_MISMATCH',{code:'SHA_MISMATCH',message:'invalid'});const e=emitted.at(-1);assert.equal(e.fields.code,'SHA_MISMATCH');});
 await test('QR HMAC token and nonce are filtered',async()=>{context.diagLog('ERROR','LAN','AUTH_FAILED',{token:'abc',hmacSecret:'def',nonce:'ghi',qrPayload:'DOLD-DIRECT-SYNC/1:SECRET',code:'AUTH_FAILED'});const f=emitted.at(-1).fields;assert.deepEqual(Object.keys(f),['code']);});
 await test('signature raw points and PNG are filtered',async()=>{context.diagLog('INFO','SIGNATURE','DRAFT_SAVED',{rawPoints:'1,2,3',coordinates:'4,5',pngBase64:'secret',points:221,strokes:2});const f=emitted.at(-1).fields;assert(!('rawPoints'in f));assert(!('coordinates'in f));assert(!('pngBase64'in f));assert.equal(f.points,'221');assert.equal(f.strokes,'2');});
 await test('LAN chunk event carries transfer chunk attempt',async()=>{context.diagLog('INFO','LAN','CHUNK_RX',{transfer:'abc123',chunk:'17/71',bytes:262144,attempt:1,status:'OK'});const f=emitted.at(-1).fields;assert.equal(f.transfer,'abc123');assert.equal(f.chunk,'17/71');assert.equal(f.attempt,'1');});
 await test('semantic summary carries apply counters',async()=>{context.diagLog('INFO','SYNC','APPLY',{received:6,applied:4,duplicates:2,conflicts:0,rejected:0});const f=emitted.at(-1).fields;assert.equal(f.applied,'4');assert.equal(f.duplicates,'2');assert.equal(f.conflicts,'0');});
 await test('status exposes count size and last event',async()=>{context.renderDiagnosticStatus();assert(elements.diagnosticStats.textContent.includes('Kirjeid: 4'));assert(elements.diagnosticStats.textContent.includes('2026-10-27 18:00:03.000'));});
 console.log(`Diagnostic JS: ${tests.length}/10 PASS`);if(process.exitCode)process.exit(process.exitCode);
})();
