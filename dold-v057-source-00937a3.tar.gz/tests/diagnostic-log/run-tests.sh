#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="${TMPDIR:-/tmp}/dold-diagnostic-tests"
rm -rf "$OUT" && mkdir -p "$OUT"
if command -v javac >/dev/null 2>&1; then
  javac -d "$OUT" "$ROOT/app/src/main/java/ee/dold/techcontrol/DiagnosticLogStore.java" "$ROOT/tests/diagnostic-log/DiagnosticLogStoreTest.java"
  java -cp "$OUT" ee.dold.techcontrol.DiagnosticLogStoreTest
else
  python3 - "$ROOT" "$OUT/DiagnosticHarness.java" <<'PY'
import re,sys
from pathlib import Path
root=Path(sys.argv[1]);out=Path(sys.argv[2])
store=(root/'app/src/main/java/ee/dold/techcontrol/DiagnosticLogStore.java').read_text()
test=(root/'tests/diagnostic-log/DiagnosticLogStoreTest.java').read_text()
imports='\n'.join(dict.fromkeys(re.findall(r'^import .*?;$',store+'\n'+test,re.M)))
store=re.sub(r'^package .*?;\s*','',store);store=re.sub(r'^import .*?;\s*','',store,flags=re.M).replace('public final class DiagnosticLogStore','final class DiagnosticLogStore')
test=re.sub(r'^package .*?;\s*','',test);test=re.sub(r'^import .*?;\s*','',test,flags=re.M).replace('public final class DiagnosticLogStoreTest','public final class DiagnosticHarness')
out.write_text(imports+'\n'+test+'\n'+store)
PY
  java "$OUT/DiagnosticHarness.java"
fi
node "$ROOT/tests/diagnostic-log/diagnostic-log.test.cjs"
