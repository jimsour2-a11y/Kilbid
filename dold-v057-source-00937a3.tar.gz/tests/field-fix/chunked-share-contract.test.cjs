const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../..');
const js=fs.readFileSync(path.join(root,'app/src/main/assets/DOLD_TechControl_v0.5.3.js'),'utf8');
const java=fs.readFileSync(path.join(root,'app/src/main/java/ee/dold/techcontrol/MainActivity.java'),'utf8');
const checks=[];
function check(name,condition){assert(condition,name);checks.push(name);console.log('PASS '+name);}
check('both DOLD ZIP package share actions use application/zip',/WORK_PACKAGE_MIME='application\/zip'/.test(js)&&/SYNC_PACKAGE_MIME='application\/zip'/.test(js));
check('sync package retains .dtcs filename extension',/function syncPackageName\(mode\)[\s\S]*?\.dtcs`/.test(js));
check('work handoff retains .dtc filename extension',/function workPackageName\(\)[\s\S]*?\.dtc`/.test(js));
check('FileProvider send includes stream URI and read grant',/send\.putExtra\(Intent\.EXTRA_STREAM, uri\)[\s\S]*?FLAG_GRANT_READ_URI_PERMISSION/.test(java));
check('FileProvider send adds ClipData URI read grant',/send\.setClipData\(ClipData\.newUri\(getContentResolver\(\), "DOLD TechControl package", uri\)\)/.test(java));
check('sync importer continues routing by package manifest format',/manifest\.format!==SYNC_PACKAGE_FORMAT/.test(js)&&/manifest\.format!==WORK_PACKAGE_FORMAT/.test(js));
console.log(`S3.1_SHARE ${checks.length}/${checks.length} PASS`);
