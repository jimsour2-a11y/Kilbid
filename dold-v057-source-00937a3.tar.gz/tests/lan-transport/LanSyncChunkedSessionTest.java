package ee.dold.techcontrol;

import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.util.Arrays;

/** Exercises the authenticated native multi-exchange path with package-sized synthetic data. */
public final class LanSyncChunkedSessionTest {
    private static int passed;
    private static int failed;
    private static final int CHUNK_BYTES = 256 * 1024;

    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    private static void test(String name, Runnable body) {
        try { body.run(); passed++; System.out.println("PASS " + name); }
        catch (Throwable t) { failed++; System.err.println("FAIL " + name + ": " + t); }
    }

    private static LanSyncTransport transport() throws Exception {
        return new LanSyncTransport(InetAddress::getLoopbackAddress);
    }

    private static LanSyncTransport.HostStatus awaitRequest(LanSyncTransport host) throws Exception {
        long deadline=System.currentTimeMillis()+5000L;
        do {
            LanSyncTransport.HostStatus status=host.getHostStatus();
            if ("REQUEST_RECEIVED".equals(status.status)||"ACK_RECEIVED".equals(status.status)) return status;
            Thread.sleep(2L);
        } while(System.currentTimeMillis()<deadline);
        throw new AssertionError("host request timed out: "+host.getHostStatus().status);
    }

    private static LanSyncTransport.ClientResult awaitClient(LanSyncTransport client,LanSyncTransport.ClientJob job) throws Exception {
        long deadline=System.currentTimeMillis()+5000L;
        do {
            LanSyncTransport.ClientJob current=client.getClientJob(job.id);
            if(current!=null&&current.getResult()!=null)return current.getResult();
            Thread.sleep(2L);
        } while(System.currentTimeMillis()<deadline);
        throw new AssertionError("client exchange timed out");
    }

    private static byte[] frame(int index, byte[] source, int start, int length) {
        ByteBuffer buffer=ByteBuffer.allocate(4+length);buffer.putInt(index);buffer.put(source,start,length);return buffer.array();
    }

    private static void roundTrip(int packageBytes) throws Exception {
        byte[] source=new byte[packageBytes];for(int i=0;i<source.length;i++)source[i]=(byte)((i*131+packageBytes*17)^(i>>>7));
        int chunks=(packageBytes+CHUNK_BYTES-1)/CHUNK_BYTES;
        byte[] rebuilt=new byte[packageBytes];
        try(LanSyncTransport host=transport();LanSyncTransport client=transport()){
            LanSyncTransport.StartResult started=host.startHostChunkedDeferredForTest("db-chunk-"+packageBytes,60_000L,LanSyncTransport.MAX_CHUNKED_EXCHANGES);
            check("STARTED".equals(started.status),"chunked host did not start: "+started.status);
            int offset=0;
            for(int index=0;index<chunks;index++){
                int length=Math.min(CHUNK_BYTES,packageBytes-offset);byte[] request=frame(index,source,offset,length);
                LanSyncTransport.ClientJob job=client.startClient(started.pairing,"db-chunk-"+packageBytes,request);
                LanSyncTransport.HostStatus event=awaitRequest(host);
                check(Arrays.equals(request,event.receivedPayload),"request bytes changed at chunk "+index);
                check(host.respondHost(event.receivedPayload,index==chunks-1),"host rejected chunk response "+index);
                LanSyncTransport.ClientResult reply=awaitClient(client,job);
                check(reply.isSuccess()&&Arrays.equals(request,reply.payload),"response bytes changed at chunk "+index+": "+reply.status);
                ByteBuffer echoed=ByteBuffer.wrap(reply.payload);check(echoed.getInt()==index,"sequence index changed at chunk "+index);
                echoed.get(rebuilt,offset,length);offset+=length;client.consumeClientJob(job.id);
            }
            check(Arrays.equals(source,rebuilt),"reassembled package differs at size "+packageBytes);
            long deadline=System.currentTimeMillis()+3000L;
            while(!"COMPLETED".equals(host.getHostStatus().status)&&System.currentTimeMillis()<deadline)Thread.sleep(2L);
            check("COMPLETED".equals(host.getHostStatus().status),"multi-exchange listener did not close after terminal frame");
        }
    }

    public static void main(String[] args) {
        test("100 KB authenticated chunk round-trip",()->{try{roundTrip(100*1024);}catch(Exception e){throw new RuntimeException(e);}});
        test("just below 1 MiB authenticated chunk round-trip",()->{try{roundTrip(1024*1024-1);}catch(Exception e){throw new RuntimeException(e);}});
        test("above 1 MiB authenticated chunk round-trip",()->{try{roundTrip(1024*1024+37);}catch(Exception e){throw new RuntimeException(e);}});
        test("5 MiB authenticated chunk round-trip",()->{try{roundTrip(5*1024*1024);}catch(Exception e){throw new RuntimeException(e);}});
        test("20 MiB authenticated chunk round-trip",()->{try{roundTrip(20*1024*1024);}catch(Exception e){throw new RuntimeException(e);}});
        if(failed!=0)throw new AssertionError("S3.1_NATIVE "+passed+"/"+(passed+failed)+" passed");
        System.out.println("S3.1_NATIVE "+passed+"/"+passed+" PASS");
    }
}
