#!/usr/bin/env sh
set -eu

PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TEST_ROOT="$PROJECT_ROOT/tests/lan-transport"
OUT_DIR=$(mktemp -d "${TMPDIR:-/tmp}/dold-lan-chunk-tests.XXXXXX")
trap 'rm -rf "$OUT_DIR"' EXIT HUP INT TERM

java -m jdk.compiler/com.sun.tools.javac.Main -Xlint:all -d "$OUT_DIR" \
  "$PROJECT_ROOT/app/src/main/java/ee/dold/techcontrol/LanSyncTransport.java" \
  "$TEST_ROOT/LanSyncChunkedSessionTest.java"
java -cp "$OUT_DIR" ee.dold.techcontrol.LanSyncChunkedSessionTest
