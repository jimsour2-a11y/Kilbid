const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'../..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'app/src/main/assets/DOLD_TechControl_v0.5.3.js'),'utf8');
let passed=0;function check(name,value){assert(value,name);passed++;console.log('PASS',name);}

const dataSection=html.slice(html.indexOf('<section id="dataTab">'),html.indexOf('<section id="signaturesTab"'));
const signatureSection=html.slice(html.indexOf('<section id="signaturesTab"'),html.indexOf('<section id="settingsTab"'));
check('Allkirjad is a top-level navigation tab',html.includes('id="tabSignatures"')&&html.includes("showTab('signatures')")&&html.includes('id="signaturesTab"'));
check('Andmed no longer contains the signature list',!dataSection.includes('signatureDraftList')&&!dataSection.includes('ALLKIRJAD JA MUSTANDID')&&signatureSection.includes('signatureDraftList'));
check('existing local draft collection is reused',/Android\.listSignatureDrafts\(\)/.test(js)&&!/'signatureDraftsCopy'|"signatureDraftsCopy"/.test(js));

class Classes{constructor(values=[]){this.values=new Set(values)}add(v){this.values.add(v)}remove(v){this.values.delete(v)}contains(v){return this.values.has(v)}}
const elements={
 signatureTargetFilter:{value:''},signatureStatusFilter:{value:''},signatureSearch:{value:''},signatureSort:{value:'newest'},
 signatureDraftList:{innerHTML:''},signatureSummary:{innerHTML:''},signatureLoadMore:{textContent:'',classList:new Classes(['hidden'])}
};
const context={$:id=>elements[id]||null,esc:v=>String(v??'').replace(/[&<>"']/g,''),localDateTime:v=>`time-${v}`};context.window=context;
vm.createContext(context);
const start=js.indexOf('const SIGNATURE_LIST_PAGE_SIZE='),end=js.indexOf('async function refreshSignatureDrafts()',start);assert(start>=0&&end>start);
vm.runInContext(js.slice(start,end),context);
const draft=(targetType,kilpId,recordId,signatureId,signerName,time,label,retryable=false)=>({draft:{targetType,kilpId,recordId,signatureId,signerName,captureEndedAtUtcMs:time,antiReuse:{result:'UNIQUE',scope:'LOCAL_KNOWN_DATA'}},state:{label,retryable},category:label.startsWith('Kehtiv')?'valid':label==='Tühistatud'?'revoked':label.includes('lisamata')?'unsaved':'other',order:time});
const fixtures=[
 draft('Kontroll','EK-052','dtc-kontroll-alpha','dtc-sign-one','Vladimir J',300,'Kehtiv (kohalikult kontrollitud)'),
 draft('Parandus','EK-029','dtc-work-beta','dtc-sign-two','Risto K',200,'Tööfailis lisamata',true),
 draft('Kontroll','EK-003','dtc-kontroll-old','dtc-sign-three','Janar K',100,'Tühistatud')
];
context.fixtures=fixtures;vm.runInContext('signatureListState.entries=fixtures;signatureListState.loaded=true;signatureListState.visible=SIGNATURE_LIST_PAGE_SIZE',context);
const filtered=()=>vm.runInContext('signatureFilteredEntries()',context);
elements.signatureTargetFilter.value='Kontroll';check('Kontroll target filter',filtered().length===2&&filtered().every(x=>x.draft.targetType==='Kontroll'));
elements.signatureTargetFilter.value='Parandus';check('Parandus target filter',filtered().length===1&&filtered()[0].draft.recordId==='dtc-work-beta');
elements.signatureTargetFilter.value='';let statusOk=true;for(const [value,category] of [['valid','valid'],['unsaved','unsaved'],['revoked','revoked']]){elements.signatureStatusFilter.value=value;const rows=filtered();statusOk=statusOk&&rows.length===1&&rows[0].category===category;}check('real workbook status filters',statusOk);
elements.signatureStatusFilter.value='';elements.signatureSearch.value='ek-029';check('EK search is case-insensitive',filtered().length===1&&filtered()[0].draft.kilpId==='EK-029');
let idsOk=true;for(const query of ['DTC-KONTROLL-ALPHA','dtc-work-beta','DTC-SIGN-THREE']){elements.signatureSearch.value=query;idsOk=idsOk&&filtered().length===1;}check('KontrollID ParandusID and AllkiriID search',idsOk);
elements.signatureSearch.value='risto k';check('signer search is case-insensitive',filtered().length===1&&filtered()[0].draft.signerName==='Risto K');
elements.signatureSearch.value='';elements.signatureSort.value='newest';check('newest signatures are first by default',filtered().map(x=>x.draft.signatureId).join(',')==='dtc-sign-one,dtc-sign-two,dtc-sign-three');

context.many=Array.from({length:75},(_,i)=>draft('Kontroll',`EK-${String(i+1).padStart(3,'0')}`,`control-${i}`,`sign-${i}`,'Tester',i+1,'Kehtiv'));
vm.runInContext('signatureListState.entries=many;signatureListState.loaded=true;signatureListState.visible=SIGNATURE_LIST_PAGE_SIZE;renderSignatureDrafts()',context);
const firstPage=(elements.signatureDraftList.innerHTML.match(/class="signature-card/g)||[]).length;vm.runInContext('showMoreSignatures()',context);const secondPage=(elements.signatureDraftList.innerHTML.match(/class="signature-card/g)||[]).length;
check('NÄITA ROHKEM adds the next bounded page',firstPage===50&&secondPage===75&&elements.signatureLoadMore.classList.contains('hidden'));

context.fixtures=fixtures;vm.runInContext('signatureListState.entries=fixtures;signatureListState.loaded=true;signatureListState.visible=50;renderSignatureDrafts()',context);
check('KINNITA XLSX-I keeps the existing retry action',elements.signatureDraftList.innerHTML.includes('KINNITA XLSX-I')&&elements.signatureDraftList.innerHTML.includes("retryProductionSignature('dtc-sign-two')"));
check('revoked signature remains visible',elements.signatureDraftList.innerHTML.includes('Tühistatud')&&elements.signatureDraftList.innerHTML.includes('dtc-sign-three'));
check('valid signature remains visible',elements.signatureDraftList.innerHTML.includes('Kehtiv (kohalikult kontrollitud)')&&elements.signatureDraftList.innerHTML.includes('dtc-sign-one'));
check('narrow viewport keeps cards and actions bounded',/@media\(max-width:390px\)[^{]*\{[^}]*\.signatureListActions button,#signatureLoadMore\{width:100%\}/.test(html)&&/\.signature-card \.signatureIds\{overflow-wrap:anywhere;word-break:break-word\}/.test(html)&&/nav\{[^}]*overflow-x:auto/.test(html));
check('light and dark theme contracts cover signature cards',/\.signature-card\{[^}]*background:var\(--card\)/.test(html)&&/:root\[data-theme="dark"\] \.signature-card/.test(html));

console.log(`SIGNATURE LIST UI ${passed}/16 PASS`);
